// FS AI — Autonomy task-queue tests.
//
// Queue behaviour against a REAL SQLite database built from
// database/schema.sql + migrations 005 + 006 + database/seed.sql
// (fresh-deploy path) via node:sqlite, behind the same minimal
// D1-compatible adapter as tests/real-db.test.js.
//
// NOTE (pre-existing condition, local test DBs only): migration 004 is
// NOT applied here. database/schema.sql already contains 004's changes
// (articles.publish_at and ai_agents.status), so applying 004 after
// schema.sql fails with a duplicate-column error. The live D1 database
// is unaffected — it was built by the incremental migration chain.
// The orchestrator is exercised directly via handleAutonomy() because
// /api/autonomy is NOT wired into backend/worker.js yet (see
// docs/AUTONOMY-INTEGRATION-PATCH.md).
//
// Run: node --test tests/autonomy-queue.test.js (or: npm test)
// Requires node:sqlite (Node >= 22.5; this repo runs Node 24).
'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { DatabaseSync } = require('node:sqlite');
const { handleAutonomy } = require('../backend/routes/orchestrator.js');
const { enqueueTask, runTask } = require('../backend/routes/scheduler.js');

const ROOT = path.join(__dirname, '..');
const WORKER_URL = 'http://localhost';

// Split a SQL file into statements: ';' outside single-quoted strings
// ends a statement; '--' starts a line comment (outside strings).
// Copied from tests/real-db.test.js.
function splitSql(text) {
  const stmts = [];
  let cur = '';
  let inStr = false;
  let inComment = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];
    if (inComment) {
      if (ch === '\n') { inComment = false; cur += ch; }
      continue;
    }
    if (inStr) {
      cur += ch;
      if (ch === "'") {
        if (next === "'") { cur += next; i++; } else inStr = false;
      }
      continue;
    }
    if (ch === '-' && next === '-') { inComment = true; i++; continue; }
    if (ch === "'") { inStr = true; cur += ch; continue; }
    if (ch === ';') { cur += ch; stmts.push(cur); cur = ''; continue; }
    cur += ch;
  }
  if (cur.trim()) stmts.push(cur);
  return stmts.filter((s) => s.trim());
}

function buildDb(files) {
  const db = new DatabaseSync(':memory:');
  for (const file of files) {
    const text = fs.readFileSync(path.join(ROOT, file), 'utf8');
    for (const stmt of splitSql(text)) db.exec(stmt);
  }
  return db;
}

// Minimal D1-compatible adapter over node:sqlite (copied from
// tests/real-db.test.js).
function makeRealD1(db) {
  return {
    prepare(sql) {
      const stmt = db.prepare(sql);
      const bound = (params) => ({
        all: () => Promise.resolve({ results: stmt.all(...params) }),
        run: () => Promise.resolve((() => {
          const r = stmt.run(...params);
          return { success: true, meta: { changes: r.changes, last_row_id: r.lastInsertRowid } };
        })()),
      });
      return {
        bind: (...params) => bound(params),
        all: () => bound([]).all(),
        run: () => bound([]).run(),
      };
    },
  };
}

// Fresh real DB per test: schema + autonomy migrations 005/006 + seed.
// Migration 004 is deliberately NOT applied (see the header note).
function freshEnv() {
  const db = buildDb([
    'database/schema.sql',
    'database/migrations/005_autonomy.sql',
    'database/migrations/006_llm_usage.sql',
    'database/seed.sql',
  ]);
  return { db, env: { DB: makeRealD1(db) } };
}

function autonomyReq(method, pathName, body) {
  const headers = { 'Content-Type': 'application/json' };
  if (body !== undefined) {
    return new Request(`${WORKER_URL}${pathName}`, { method, headers, body: JSON.stringify(body) });
  }
  return new Request(`${WORKER_URL}${pathName}`, { method, headers });
}

async function callAutonomy(env, method, pathName, body) {
  const res = await handleAutonomy(autonomyReq(method, pathName, body), env, {}, null);
  return { status: res.status, body: await res.json() };
}

describe('autonomy task queue — idempotency', () => {
  it('second enqueue with the same idempotency_key returns the existing task, no duplicate row', async () => {
    const { db, env } = freshEnv();
    const first = await callAutonomy(env, 'POST', '/api/autonomy/tasks', {
      agent: 'research', kind: 'daily-research',
      payload: { division: 'automotive', sources: [] },
      idempotency_key: 'test-dedupe-1',
    });
    assert.equal(first.status, 201, JSON.stringify(first.body));
    assert.equal(first.body.duplicate, false);
    assert.ok(first.body.task.id, 'first enqueue returns a task id');

    const second = await callAutonomy(env, 'POST', '/api/autonomy/tasks', {
      agent: 'research', kind: 'daily-research',
      payload: { division: 'automotive', sources: [] },
      idempotency_key: 'test-dedupe-1',
    });
    assert.equal(second.status, 200, JSON.stringify(second.body));
    assert.equal(second.body.duplicate, true);
    assert.equal(second.body.task.id, first.body.task.id, 'duplicate returns the SAME task id');

    const count = db.prepare('SELECT COUNT(*) AS n FROM agent_tasks WHERE idempotency_key = ?').get('test-dedupe-1');
    assert.equal(count.n, 1, 'exactly one row exists for the idempotency key');
  });

  it('enqueueTask directly: duplicate returns the existing row', async () => {
    const { db, env } = freshEnv();
    const a = await enqueueTask(env, { agent: 'seo', kind: 'seo-pass', payload: { article_id: 1 }, idempotency_key: 'direct-dedupe' });
    const b = await enqueueTask(env, { agent: 'seo', kind: 'seo-pass', payload: { article_id: 1 }, idempotency_key: 'direct-dedupe' });
    assert.equal(a.ok, true);
    assert.equal(b.ok, true);
    assert.equal(b.duplicate, true);
    assert.equal(b.task.id, a.task.id);
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM agent_tasks').get().n, 1);
  });
});

describe('autonomy task queue — retry bounds', () => {
  // A fact-check for a non-existent article always fails, which is a
  // deterministic way to exercise the retry path without touching the
  // network or an LLM.
  async function failingTask(env) {
    const res = await enqueueTask(env, {
      agent: 'fact-checking', kind: 'fact-check', payload: { article_id: 99999 },
      idempotency_key: 'test-retry-1',
    });
    assert.equal(res.ok, true);
    return res.task.id;
  }

  it('failed task with attempts < max_attempts returns to queued with a future scheduled_for', async () => {
    const { db, env } = freshEnv();
    const id = await failingTask(env);
    const before = Date.now();
    const result = await runTask(env, id);
    assert.equal(result.ok, true);
    assert.equal(result.outcome, 'failed');
    assert.equal(result.requeued, true);
    assert.equal(result.attempts, 1);
    assert.ok(result.scheduled_for, 'requeue sets scheduled_for');
    assert.ok(new Date(result.scheduled_for).getTime() > before, 'scheduled_for is in the future');

    const row = db.prepare('SELECT status, attempts, scheduled_for FROM agent_tasks WHERE id = ?').get(id);
    assert.equal(row.status, 'queued');
    assert.equal(row.attempts, 1);
    assert.ok(new Date(row.scheduled_for).getTime() > before);
    // The failure is logged: one run + one log row for this task.
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM agent_runs WHERE task_id = ?').get(id).n, 1);
    assert.ok(db.prepare('SELECT COUNT(*) AS n FROM agent_logs WHERE run_id IN (SELECT id FROM agent_runs WHERE task_id = ?)').get(id).n >= 1);
  });

  it('failed task with attempts >= max_attempts stays failed', async () => {
    const { db, env } = freshEnv();
    const id = await failingTask(env);
    // Burn the retries: run once (attempts 1, requeued), then force
    // attempts to max_attempts and run again.
    await runTask(env, id);
    db.prepare('UPDATE agent_tasks SET attempts = 3 WHERE id = ?').run(id);
    const result = await runTask(env, id);
    assert.equal(result.ok, true);
    assert.equal(result.outcome, 'failed');
    assert.equal(result.requeued, false);
    assert.equal(result.attempts, 4);

    const row = db.prepare('SELECT status, attempts FROM agent_tasks WHERE id = ?').get(id);
    assert.equal(row.status, 'failed', 'task stays failed once retries are exhausted');
    assert.equal(row.attempts, 4);
  });

  it('a done task cannot run again (409)', async () => {
    const { env } = freshEnv();
    const res = await enqueueTask(env, {
      agent: 'analytics', kind: 'snapshot', payload: {},
      idempotency_key: 'test-rerun-1',
    });
    const first = await runTask(env, res.task.id);
    assert.equal(first.ok, true);
    assert.equal(first.outcome, 'no-op', 'analytics with no source returns no-op, which is a terminal outcome');
    const second = await runTask(env, res.task.id);
    assert.equal(second.ok, false);
    assert.equal(second.status, 409);
  });
});

describe('autonomy task queue — input validation (400s)', () => {
  it('invalid agent is rejected with 400', async () => {
    const { env } = freshEnv();
    const res = await callAutonomy(env, 'POST', '/api/autonomy/tasks', {
      agent: 'not-an-agent', kind: 'something',
    });
    assert.equal(res.status, 400);
    assert.match(res.body.error, /agent must be one of/);
  });

  it('missing/empty kind is rejected with 400', async () => {
    const { env } = freshEnv();
    const missing = await callAutonomy(env, 'POST', '/api/autonomy/tasks', { agent: 'research' });
    assert.equal(missing.status, 400);
    const empty = await callAutonomy(env, 'POST', '/api/autonomy/tasks', { agent: 'research', kind: '   ' });
    assert.equal(empty.status, 400);
  });

  it('priority outside 1–10 is rejected with 400', async () => {
    const { env } = freshEnv();
    for (const bad of [0, 11, 2.5, 'high']) {
      const res = await callAutonomy(env, 'POST', '/api/autonomy/tasks', {
        agent: 'research', kind: 'daily-research', priority: bad,
      });
      assert.equal(res.status, 400, `priority ${JSON.stringify(bad)} must be rejected`);
    }
    const ok = await callAutonomy(env, 'POST', '/api/autonomy/tasks', {
      agent: 'research', kind: 'daily-research', priority: 10,
    });
    assert.equal(ok.status, 201);
    assert.equal(ok.body.task.priority, 10);
  });

  it('unknown division_id is rejected with 400', async () => {
    const { env } = freshEnv();
    const res = await callAutonomy(env, 'POST', '/api/autonomy/tasks', {
      agent: 'research', kind: 'daily-research', division_id: 99999,
    });
    assert.equal(res.status, 400);
    assert.match(res.body.error, /Unknown division_id/);
  });

  it('non-existent task id returns 404 on run', async () => {
    const { env } = freshEnv();
    const res = await callAutonomy(env, 'POST', '/api/autonomy/tasks/99999/run', {});
    assert.equal(res.status, 404);
  });
});

describe('autonomy settings — allowlist', () => {
  it("autonomy_level '1'/'2'/'3' are accepted and stored; '4' is rejected", async () => {
    const { db, env } = freshEnv();
    for (const level of ['1', '2', '3']) {
      const res = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'autonomy_level', value: level });
      assert.equal(res.status, 200, `level ${level}: ${JSON.stringify(res.body)}`);
      assert.equal(db.prepare("SELECT value FROM autonomy_settings WHERE key = 'autonomy_level'").get().value, level);
    }
    const bad = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'autonomy_level', value: '4' });
    assert.equal(bad.status, 400);
    assert.match(bad.body.error, /autonomy_level/);
    assert.equal(db.prepare("SELECT value FROM autonomy_settings WHERE key = 'autonomy_level'").get().value, '3',
      'rejected value must not overwrite the stored level');
  });

  // Coordinator change 2026-11-21 (owner full-automation brief):
  // publishing_mode now accepts 'approved_only' | 'auto'. 'auto'
  // alone publishes NOTHING — auto-publish also needs
  // auto_publishing='on' AND auto_publish_eligible_since set.
  it("publishing_mode only accepts 'approved_only' or 'auto'", async () => {
    const { db, env } = freshEnv();
    for (const bad of ['approved', 'all', '']) {
      const res = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'publishing_mode', value: bad });
      assert.equal(res.status, 400, `publishing_mode ${JSON.stringify(bad)} must be rejected`);
    }
    const ok = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'publishing_mode', value: 'approved_only' });
    assert.equal(ok.status, 200);
    assert.equal(db.prepare("SELECT value FROM autonomy_settings WHERE key = 'publishing_mode'").get().value, 'approved_only');
    const auto = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'publishing_mode', value: 'auto' });
    assert.equal(auto.status, 200, 'publishing_mode auto must be accepted (three-part enablement)');
    assert.equal(db.prepare("SELECT value FROM autonomy_settings WHERE key = 'publishing_mode'").get().value, 'auto');
  });

  // Coordinator change 2026-11-21 (owner full-automation brief):
  // social_auto_post now accepts 'off' | 'draft_only' | 'on'.
  // Creation is always draft-only; 'on' still never posts without a
  // connected account and an explicit owner publish action.
  it("social_auto_post only accepts 'off', 'draft_only' or 'on'", async () => {
    const { db, env } = freshEnv();
    for (const bad of ['auto', 'approved']) {
      const res = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'social_auto_post', value: bad });
      assert.equal(res.status, 400, `social_auto_post ${JSON.stringify(bad)} must be rejected`);
    }
    const ok = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'social_auto_post', value: 'off' });
    assert.equal(ok.status, 200);
    assert.equal(db.prepare("SELECT value FROM autonomy_settings WHERE key = 'social_auto_post'").get().value, 'off');
    for (const good of ['draft_only', 'on']) {
      const res = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'social_auto_post', value: good });
      assert.equal(res.status, 200, `social_auto_post ${JSON.stringify(good)} must be accepted`);
      assert.equal(db.prepare("SELECT value FROM autonomy_settings WHERE key = 'social_auto_post'").get().value, good);
    }
  });

  it('max_articles_per_day accepts 0–3 only; unknown keys are rejected', async () => {
    const { db, env } = freshEnv();
    const ok = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'max_articles_per_day', value: 2 });
    assert.equal(ok.status, 200);
    assert.equal(db.prepare("SELECT value FROM autonomy_settings WHERE key = 'max_articles_per_day'").get().value, '2');
    for (const bad of [-1, 4, 1.5]) {
      const res = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'max_articles_per_day', value: bad });
      assert.equal(res.status, 400, `max_articles_per_day ${bad} must be rejected`);
    }
    const unknown = await callAutonomy(env, 'POST', '/api/autonomy/settings', { key: 'llm_provider', value: 'groq' });
    assert.equal(unknown.status, 400, 'spending/account keys are never settable through this endpoint');
  });
});

describe('autonomy status — real counts + LLM block', () => {
  it('GET /api/autonomy/status reports real task counts and a paused LLM block with no provider', async () => {
    const { env } = freshEnv();
    await enqueueTask(env, { agent: 'research', kind: 'daily-research', payload: {}, idempotency_key: 'status-1' });
    const res = await callAutonomy(env, 'GET', '/api/autonomy/status');
    assert.equal(res.status, 200);
    assert.equal(res.body.autonomyLevel, '3');
    assert.equal(res.body.tasks.queued, 1);
    assert.equal(res.body.tasks.done, 0);
    assert.equal(res.body.revenue, '$0.00');
    assert.equal(res.body.traffic, 'Data unavailable');
    assert.equal(res.body.publishingMode, 'approved_only');
    assert.equal(res.body.llm.provider, 'none');
    assert.equal(res.body.llm.status, 'paused');
    assert.equal(res.body.llm.generationPaused, true);
    assert.ok(Array.isArray(res.body.agents) && res.body.agents.length === 10, '10 queue-agent roles reported');
  });

  it('GET /api/autonomy/llm reports workers-ai only as the provider order (no fallback) with no keys or binding', async () => {
    const { env } = freshEnv();
    const res = await callAutonomy(env, 'GET', '/api/autonomy/llm');
    assert.equal(res.status, 200);
    assert.equal(res.body.generationPaused, true);
    // M1 policy change (2026-11-21): Workers AI is the ONLY provider —
    // no Groq/Gemini fallback exists, so the order is workers-ai alone.
    assert.deepEqual(res.body.order, ['workers-ai']);
    assert.ok(res.body.providers.every((p) => p.status === 'not-configured'),
      'no provider is available without a binding or a key');
    assert.match(res.body.reason, /not bound|not set/);
  });
});

describe('autonomy task queue — manual re-enqueue of a terminal task (live #33, 2026-11-22)', () => {
  // Live #33 shape: the dashboard Correct button enqueues with the dated
  // key `manual-correct-33-2026-11-22`. The first click created task #44
  // (kind 'correct'); its correction run #171 FAILED on the validator
  // defect; the Re-check then reused the same row and forced its kind to
  // 'fact-check', and run #172 finished, leaving the row status 'done',
  // attempts 2/3. The next same-day Correct click returned that dead row
  // unchanged ("already existed — run it from the task queue"), but a
  // 'done' task has no Run button and the Retry button renders only for
  // 'failed' tasks — so the correction could never be retried.
  // A manual re-enqueue must re-queue a terminal task for the requested
  // work instead of returning it dead. Scheduled callers are unaffected:
  // they call enqueueTask() directly without the manual flag, so a
  // completed daily task is never re-run by a second daily-run pass.
  const KEY = 'manual-correct-33-2026-11-22';

  async function correctViaEndpoint(env, articleId) {
    return callAutonomy(env, 'POST', '/api/autonomy/tasks', {
      agent: 'fact-checking', kind: 'correct',
      payload: { article_id: articleId },
      idempotency_key: KEY,
    });
  }

  it('second same-day Correct enqueue re-queues the done task as a runnable correct task', async () => {
    const { db, env } = freshEnv();
    const first = await correctViaEndpoint(env, 33);
    assert.equal(first.status, 201, JSON.stringify(first.body));
    assert.equal(first.body.duplicate, false);
    const id = first.body.task.id;
    // Live #44 shape after runs #171 (correction failed) + #172 (re-check done).
    db.prepare("UPDATE agent_tasks SET kind = 'fact-check', status = 'done', attempts = 2 WHERE id = ?").run(id);

    const second = await correctViaEndpoint(env, 33);
    assert.equal(second.status, 200, JSON.stringify(second.body));
    assert.equal(second.body.duplicate, true, 'the row is reused, not duplicated');
    assert.equal(second.body.task.id, id, 'same task id');
    assert.equal(second.body.requeued, true, 'manual re-enqueue of a terminal task re-queues it');
    assert.equal(second.body.task.status, 'queued', 'terminal task is re-queued for the requested work');
    assert.equal(second.body.task.kind, 'correct', 'kind is restored to the requested correct');
    assert.equal(second.body.task.attempts, 0, 'attempts reset like an explicit owner retry');
    assert.equal(second.body.task.scheduled_for, null, 'no backoff: runs when the owner runs it');

    const row = db.prepare('SELECT status, kind, attempts, scheduled_for FROM agent_tasks WHERE id = ?').get(id);
    assert.equal(row.status, 'queued');
    assert.equal(row.kind, 'correct');
    assert.equal(row.attempts, 0);
    assert.equal(row.scheduled_for, null);
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM agent_tasks').get().n, 1, 'still exactly one row');
  });

  it('a failed terminal task re-queues too (attempts reset, terminal state cleared)', async () => {
    const { db, env } = freshEnv();
    const first = await correctViaEndpoint(env, 33);
    const id = first.body.task.id;
    db.prepare("UPDATE agent_tasks SET status = 'failed', attempts = 3 WHERE id = ?").run(id);
    db.prepare("INSERT INTO agent_runs (task_id, agent, started_at, finished_at, outcome, detail) VALUES (?, 'fact-checking', '2026-11-22T06:45:00.000Z', '2026-11-22T06:46:00.000Z', 'failed', '{}')").run(id);

    const second = await correctViaEndpoint(env, 33);
    assert.equal(second.status, 200, JSON.stringify(second.body));
    assert.equal(second.body.requeued, true);
    assert.equal(second.body.task.status, 'queued');
    assert.equal(second.body.task.attempts, 0);
    const row = db.prepare('SELECT status, attempts FROM agent_tasks WHERE id = ?').get(id);
    assert.equal(row.status, 'queued');
    assert.equal(row.attempts, 0);
  });

  it('second enqueue while the task is queued returns the existing row unchanged (no duplicate run)', async () => {
    const { db, env } = freshEnv();
    const first = await correctViaEndpoint(env, 33);
    assert.equal(first.status, 201);
    const second = await correctViaEndpoint(env, 33);
    assert.equal(second.status, 200, JSON.stringify(second.body));
    assert.equal(second.body.duplicate, true);
    assert.equal(second.body.task.id, first.body.task.id);
    assert.equal(second.body.task.status, 'queued');
    assert.equal(second.body.task.kind, 'correct');
    assert.equal(second.body.task.attempts, 0);
    assert.equal(second.body.requeued, undefined, 'a queued task is NOT re-queued');
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM agent_tasks').get().n, 1);
  });

  it('second enqueue while the task is running returns the existing row unchanged', async () => {
    const { db, env } = freshEnv();
    const first = await correctViaEndpoint(env, 33);
    const id = first.body.task.id;
    db.prepare("UPDATE agent_tasks SET status = 'running', attempts = 1 WHERE id = ?").run(id);
    const second = await correctViaEndpoint(env, 33);
    assert.equal(second.status, 200, JSON.stringify(second.body));
    assert.equal(second.body.duplicate, true);
    assert.equal(second.body.task.id, id);
    assert.equal(second.body.task.status, 'running');
    assert.equal(second.body.task.attempts, 1, 'attempts untouched while running');
    assert.equal(second.body.requeued, undefined, 'a running task is NOT re-queued');
  });

  it('a done content-creation task is NOT re-queued by a manual duplicate (Fix 8 precedence)', async () => {
    const { db, env } = freshEnv();
    const title = 'How AI Assistants Help Small Teams Every Day';
    const key = 'manual-content-how-ai-assistants-help-small-teams-every-day-2026-11-22';
    const first = await callAutonomy(env, 'POST', '/api/autonomy/tasks', {
      agent: 'content-creation', kind: 'daily-content',
      payload: { title, division: 'automotive', sources: ['https://example.com/ai-assistants-small-teams'] },
      idempotency_key: key,
    });
    assert.equal(first.status, 201, JSON.stringify(first.body));
    const id = first.body.task.id;
    db.prepare("UPDATE agent_tasks SET status = 'done' WHERE id = ?").run(id);

    const second = await callAutonomy(env, 'POST', '/api/autonomy/tasks', {
      agent: 'content-creation', kind: 'daily-content',
      payload: { title, division: 'automotive', sources: ['https://example.com/ai-assistants-new-source'] },
      idempotency_key: key,
    });
    assert.equal(second.status, 200, JSON.stringify(second.body));
    assert.equal(second.body.duplicate, true);
    assert.equal(second.body.task.id, id);
    assert.equal(second.body.task.status, 'done', 'a done content task stays done');
    assert.equal(second.body.requeued, undefined, 'content tasks never re-queue through the duplicate path');
    assert.equal(second.body.sourceMerge.status, 'rejected', 'Fix 8: sources cannot reach an already-converted article');
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM agent_tasks').get().n, 1);
  });

  it('enqueueTask without the manual flag still returns a done task unchanged (scheduled callers unaffected)', async () => {
    const { db, env } = freshEnv();
    const a = await enqueueTask(env, { agent: 'seo', kind: 'seo-pass', payload: { article_id: 1 }, idempotency_key: 'sched-dedupe' });
    assert.equal(a.ok, true);
    db.prepare("UPDATE agent_tasks SET status = 'done' WHERE id = ?").run(a.task.id);
    const b = await enqueueTask(env, { agent: 'seo', kind: 'seo-pass', payload: { article_id: 1 }, idempotency_key: 'sched-dedupe' });
    assert.equal(b.ok, true);
    assert.equal(b.duplicate, true);
    assert.equal(b.task.id, a.task.id);
    assert.equal(b.task.status, 'done', 'without the manual flag a terminal task is returned dead, as before');
    assert.equal(b.requeued, undefined);
  });
});
