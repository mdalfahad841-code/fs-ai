/**
 * FS AI — Tools route. The 20 real free tools.
 * All tools run client-side / on the free tier; none require sign-up or payment.
 * Currency conversion uses a manually entered rate — no live-rate claim is made.
 *
 * D1 table is digital_tools (database/schema.sql) — NOT `tools`. The D1
 * rows are mapped to the fallback shape: the seed catalogue (20 rows) uses
 * different slugs from the frontend tool ids, so the API returns the D1
 * rows as stored, with the division slug joined in. `?category=` filters
 * by division slug (e.g. automotive) or by tool_type.
 *
 * FRONTEND_TOOL_IDS — the 20 tool ids the FRONTEND tools page
 * (frontend/scripts/tools.js, DEFS) actually renders, in sitemap
 * order. These are NOT the D1 slugs (e.g. D1 'currency-manual-rate'
 * vs frontend 'currency-converter', D1 'storage' vs frontend
 * 'storage-converter'): the `?tool=` URL parameter is read by the
 * frontend, so the sitemap must list the frontend ids. A parity test
 * (tests/sitemap-canonical.test.js) fails if this list drifts from
 * the frontend DEFS.
 */
export const FRONTEND_TOOL_IDS = [
  'fuel-cost', 'mileage', 'maintenance-planner', 'tyre-pressure',
  'monthly-budget', 'savings', 'loan-payment', 'currency-converter',
  'storage-converter', 'internet-speed', 'data-unit', 'file-size',
  'travel-budget', 'distance-planner', 'trip-cost', 'age-calculator',
  'percentage', 'date-calculator', 'unit-converter', 'time-calculator',
];
import { jsonOk, jsonError, d1All } from '../middleware/validation.js';

export const TOOLS = [
  { id: 1, slug: 'fuel-cost', name: 'Fuel Cost', category: 'Automotive', description: 'Estimate fuel cost for a trip from distance, mileage and fuel price.' },
  { id: 2, slug: 'mileage', name: 'Mileage', category: 'Automotive', description: 'Calculate vehicle mileage (km per litre) from distance and fuel used.' },
  { id: 3, slug: 'maintenance-planner', name: 'Maintenance Planner', category: 'Automotive', description: 'Plan routine car maintenance by date and mileage.' },
  { id: 4, slug: 'tyre-pressure', name: 'Tyre Pressure', category: 'Automotive', description: 'Convert tyre pressure between PSI, bar and kPa.' },
  { id: 5, slug: 'monthly-budget', name: 'Monthly Budget', category: 'Finance', description: 'Split monthly income using the 50/30/20 budgeting rule.' },
  { id: 6, slug: 'savings', name: 'Savings', category: 'Finance', description: 'Project savings growth from a regular monthly amount.' },
  { id: 7, slug: 'loan-payment', name: 'Loan Payment', category: 'Finance', description: 'Calculate monthly loan payments and total interest.' },
  { id: 8, slug: 'currency-manual-rate', name: 'Currency (manual rate)', category: 'Finance', description: 'Convert currency with a rate you enter yourself — no live-rate claim.' },
  { id: 9, slug: 'storage', name: 'Storage', category: 'Digital', description: 'Convert storage units: bytes, KB, MB, GB and TB.' },
  { id: 10, slug: 'internet-speed', name: 'Internet Speed', category: 'Digital', description: 'Convert internet speed units and estimate download times.' },
  { id: 11, slug: 'data-unit', name: 'Data Unit', category: 'Digital', description: 'Convert data units between bits, bytes and larger units.' },
  { id: 12, slug: 'file-size', name: 'File Size', category: 'Digital', description: 'Convert file sizes and estimate how many files fit a storage size.' },
  { id: 13, slug: 'travel-budget', name: 'Travel Budget', category: 'Travel', description: 'Plan a trip budget across transport, stay, food and activities.' },
  { id: 14, slug: 'distance', name: 'Distance', category: 'Travel', description: 'Convert distances between kilometres, miles, metres and feet.' },
  { id: 15, slug: 'trip-cost', name: 'Trip Cost', category: 'Travel', description: 'Estimate the total cost of a trip, including fuel or fares.' },
  { id: 16, slug: 'age', name: 'Age', category: 'General', description: 'Calculate age from a date of birth.' },
  { id: 17, slug: 'percentage', name: 'Percentage', category: 'General', description: 'Percentage, percentage change and percentage-of calculations.' },
  { id: 18, slug: 'date', name: 'Date', category: 'General', description: 'Date difference and adding or subtracting days from a date.' },
  { id: 19, slug: 'unit', name: 'Unit', category: 'General', description: 'General unit converter for length, weight and temperature.' },
  { id: 20, slug: 'time', name: 'Time', category: 'General', description: 'Convert time units and time-zone-friendly duration calculations.' },
];

function mapToolRow(row) {
  if (!row) return row;
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    description: row.description,
    division: row.division || null,
    divisionName: row.division_name || null,
    toolType: row.tool_type,
    formula: row.formula || null,
    isActive: row.is_active === 1,
  };
}

const TOOL_SELECT =
  'SELECT t.*, d.slug AS division, d.name AS division_name ' +
  'FROM digital_tools t LEFT JOIN business_divisions d ON d.id = t.division_id ' +
  'WHERE t.is_active = 1';

export async function handleTools(request, env) {
  const url = new URL(request.url);
  const method = request.method.toUpperCase();
  const parts = url.pathname.split('/').filter(Boolean);
  if (method !== 'GET') return jsonError('Method not allowed', 405);

  if (parts.length === 3) {
    const slug = decodeURIComponent(parts[2]);
    if (env.DB) {
      const rows = await d1All(env, `${TOOL_SELECT} AND t.slug = ? LIMIT 1`, [slug]);
      if (!rows || !rows.length) return jsonError('Tool not found', 404);
      return jsonOk({ tool: mapToolRow(rows[0]), source: 'd1' });
    }
    const tool = TOOLS.find((t) => t.slug === slug);
    if (!tool) return jsonError('Tool not found', 404);
    return jsonOk({ tool, source: 'fallback' });
  }

  const category = url.searchParams.get('category');
  if (env.DB) {
    let sql = TOOL_SELECT;
    const params = [];
    if (category) { sql += ' AND (d.slug = ? OR t.tool_type = ?)'; params.push(category, category); }
    sql += ' ORDER BY t.id ASC';
    const rows = await d1All(env, sql, params);
    const tools = (rows || []).map(mapToolRow);
    return jsonOk({ tools, total: tools.length, source: 'd1' });
  }
  const tools = category ? TOOLS.filter((t) => t.category === category) : TOOLS;
  return jsonOk({ tools, total: tools.length, source: 'fallback' });
}
