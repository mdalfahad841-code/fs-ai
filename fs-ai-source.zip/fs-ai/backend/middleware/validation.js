/**
 * FS AI — Validation middleware / helpers.
 * Input sanitisation, XSS guards (HTML escaping on output) and
 * SQL-injection guards (D1 prepared statements with bound parameters —
 * user input is never interpolated into SQL). Plus shared JSON helpers.
 */
import { escapeHtml } from '../security/crypto.js';

export function jsonOk(data, status = 200) {
  return new Response(JSON.stringify({ ok: true, ...data }), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  });
}

export function jsonError(message, status = 400, extra = {}) {
  return new Response(JSON.stringify({ ok: false, error: String(message), ...extra }), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  });
}

export function parseQuery(url) {
  return url.searchParams;
}

export function sanitiseText(value, maxLength = 500) {
  if (typeof value !== 'string') return '';
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, maxLength);
}

export function sanitiseForHtml(value) {
  return escapeHtml(sanitiseText(value, 2000));
}

export function isValidSlug(value) {
  return typeof value === 'string' && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value);
}

export function isValidEmail(value) {
  return typeof value === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value);
}

export function isSafeUrl(value) {
  if (typeof value !== 'string') return false;
  try {
    const u = new URL(value);
    return u.protocol === 'https:';
  } catch {
    return false;
  }
}

// SQL-injection guard: this codebase only ever queries D1 through prepared
// statements with bound parameters (see routes/*.js). This helper rejects
// values that look like an injection attempt if a caller ever needs a
// LIKE pattern, so a raw string can never reach SQL.
const SQL_META = /('|"|;|--|\/\*|\*\/|\b(DROP|DELETE|UPDATE|INSERT|UNION|SELECT)\b)/i;
export function assertSafeLikeParam(value) {
  if (typeof value !== 'string') return '';
  if (SQL_META.test(value)) throw new Error('Unsafe input rejected.');
  return value.replace(/[%_\\]/g, (c) => `\\${c}`);
}

export async function readJsonBody(request, maxBytes = 100 * 1024) {
  const text = await request.text();
  if (text.length > maxBytes) throw new Error('Request body too large.');
  try {
    return JSON.parse(text);
  } catch {
    throw new Error('Invalid JSON body.');
  }
}

export function validateArticleInput(body) {
  const errors = [];
  if (!body || typeof body !== 'object') return { ok: false, errors: ['Body must be a JSON object.'] };
  if (!body.title || typeof body.title !== 'string' || body.title.trim().length < 5) errors.push('title is required (at least 5 characters).');
  if (body.title && body.title.length > 200) errors.push('title must be under 200 characters.');
  if (body.division && !isValidSlug(body.division)) errors.push('division must be a valid slug.');
  if (body.excerpt && body.excerpt.length > 500) errors.push('excerpt must be under 500 characters.');
  return { ok: errors.length === 0, errors, clean: errors.length ? null : { title: sanitiseText(body.title, 200), excerpt: sanitiseText(body.excerpt || '', 500), division: body.division || null } };
}

// ---------------------------------------------------------------------------
// CMS / admin helpers (added 2026-11-13 for the CMS, newsletter, divisions
// admin, agent-control and backup work). Pure functions only — no I/O.
// ---------------------------------------------------------------------------

// Lowercase hyphenated slug from a title, e.g. "Hello World!" -> "hello-world".
export function slugify(value) {
  if (typeof value !== 'string') return '';
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 120);
}

// True when the value parses as a real date/time (ISO 8601 expected).
export function isValidIsoDateTime(value) {
  if (typeof value !== 'string' || !value.trim()) return false;
  const ms = Date.parse(value);
  return Number.isFinite(ms);
}

// Current UTC time as an ISO string (lexicographically comparable with the
// ISO timestamps stored in D1 TEXT columns).
export function nowIso() {
  return new Date().toISOString();
}

// Article statuses allowed by the articles.status CHECK constraint.
export const ARTICLE_STATUSES = ['draft', 'pending_approval', 'approved', 'published', 'archived'];

// Divisions whose single-article responses carry a general-information
// disclaimer. Worded honestly: general information only, not advice.
export const DISCLAIMER_DIVISIONS = new Set(['health-wellness', 'finance-money']);
export const GENERAL_INFO_DISCLAIMER =
  'General information only — not medical/financial advice. Consult a qualified professional.';

export function disclaimerForDivision(slug) {
  return DISCLAIMER_DIVISIONS.has(slug) ? GENERAL_INFO_DISCLAIMER : null;
}

/**
 * Derive a 120-160 character meta description from REAL article text.
 * Pure function, no I/O. Strips markdown headings and the AI-DRAFT
 * marker line, then cuts at a sentence end (preferred) or a word
 * boundary inside the 120-160 window. Returns '' when the text is too
 * short to fill the range — the caller must not invent filler text.
 * (Added 2026-11-20: the old title-only description was 77 chars and
 * could never pass the 120-160 SEO check.)
 */
export function deriveSeoDescription(text) {
  // Heading lines are removed while newlines are intact; when the input
  // is already a single line (whitespace collapsed), the line regex
  // would eat the whole string, so strip only the '#' markers instead.
  let plain = String(text || '').replace(/^AI-DRAFT[^\n]*\n?/im, '');
  plain = plain.includes('\n')
    ? plain.replace(/^#{1,6}\s+.*$/gm, ' ')
    : plain.replace(/#{1,6}\s+/g, '');
  plain = plain.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  if (plain.length < 120) return '';
  if (plain.length <= 160) return plain;
  const cut = plain.slice(0, 160);
  const sentenceEnd = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('! '), cut.lastIndexOf('? '));
  if (sentenceEnd >= 119) return cut.slice(0, sentenceEnd + 1);
  const lastSpace = cut.lastIndexOf(' ');
  if (lastSpace >= 119) return cut.slice(0, lastSpace);
  return cut;
}

// Newsletter subscriber statuses allowed by the CHECK constraint.
export const SUBSCRIBER_STATUSES = ['pending', 'subscribed', 'unsubscribed'];

// ---------------------------------------------------------------------------
// Minimal D1 helpers. All queries go through prepared statements with bound
// parameters — user input is never interpolated into SQL. Returns [] / null
// when env.DB is not bound, so callers can answer 503 honestly.
// ---------------------------------------------------------------------------

export async function d1All(env, sql, params = []) {
  if (!env || !env.DB) return null;
  const stmt = env.DB.prepare(sql);
  const bound = params.length ? stmt.bind(...params) : stmt;
  const result = await bound.all();
  return result.results || [];
}

export async function d1First(env, sql, params = []) {
  const rows = await d1All(env, sql, params);
  if (rows === null) return null;
  return rows.length ? rows[0] : undefined;
}

export async function d1Run(env, sql, params = []) {
  if (!env || !env.DB) return null;
  const stmt = env.DB.prepare(sql);
  const bound = params.length ? stmt.bind(...params) : stmt;
  return bound.run();
}

/**
 * Run several statements as ONE atomic batch (Fix Pass 2 item 5,
 * 2026-11-23 — deleteArticle's dependent-row deletes + article DELETE
 * + audit INSERT). Cloudflare D1's env.DB.batch() executes the prepared
 * statements as a single transaction: if any statement fails, the whole
 * batch is rolled back, so a failed delete can never leave half the
 * rows deleted or an audit row for an article that still exists
 * (close-out B4). Bindings that do not offer batch() (test doubles)
 * fall back to sequential d1Run calls in the same order — that fallback
 * is NOT atomic, so callers that need all-or-nothing must run against
 * a binding with batch(); real D1 always has it.
 */
export async function d1Batch(env, statements) {
  if (!env || !env.DB) return null;
  if (typeof env.DB.batch === 'function') {
    const prepared = statements.map(({ sql, params = [] }) => {
      const stmt = env.DB.prepare(sql);
      return params.length ? stmt.bind(...params) : stmt;
    });
    return env.DB.batch(prepared);
  }
  const results = [];
  for (const { sql, params = [] } of statements) results.push(await d1Run(env, sql, params));
  return results;
}

/**
 * True when an error means "the referenced column does not exist".
 * SQLite (local tests) says "table X has no column named Y"; Cloudflare
 * D1 says "no such column: Y". Phase 3 migrations 016–018 add columns
 * the parent applies live AFTER deploy, so code that writes the new
 * columns must fall back to the old column list while they are absent
 * — and must only fall back for THIS error, never for any other failure.
 */
export function isMissingColumnError(err) {
  const text = String((err && err.message) || err || '');
  return /no such column/i.test(text) || /has no column named/i.test(text);
}
