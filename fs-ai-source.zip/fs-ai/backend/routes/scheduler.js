/**
 * FS AI — Autonomy scheduler.
 *
 * Daily + weekly workflows and single-task execution against D1.
 * Every workflow step is wrapped so one failure never aborts the rest,
 * and every step writes an agent_runs row + agent_logs rows. The
 * Emergency Stop skips a whole workflow (logged, nothing runs).
 * Idempotency: enqueueTask never creates a duplicate for the same
 * idempotency_key — it returns the existing task instead.
 */
import { d1All, d1First, d1Run, nowIso, isMissingColumnError, slugify } from '../middleware/validation.js';
import { getEmergencyStop } from './admin.js';
import { publishDueArticles } from './admin-articles.js';
import { runAutonomyTask, DIVISION_RESEARCH_REGISTRY, registryIdForTask, QUEUE_AGENTS } from '../agents/autonomy-runner.js';
import { convertScaffoldToDraft, articlesCreatedToday } from '../agents/autonomy/content.js';
import { runHealthCheck } from '../services/healthcheck.js';
import { buildDailyHealthReport } from '../services/daily-health-report.js';
import { HEALTH_REPORT_EXTERNAL_PATH } from './health-external.js';
import { signInternalRequest } from '../security/crypto.js';
import { runResearch } from '../agents/autonomy/research.js';
import { runFactChecking } from '../agents/autonomy/factcheck.js';
import { runSeo } from '../agents/autonomy/seo.js';
import { evaluatePublishGate, publishGatePassed } from '../publishing/gate.js';
import { runAutoPublish } from '../agents/autonomy/publishing.js';
import { PROTECTED_TEST_ARTICLES, protectedExclusion, assertTaskNotProtected } from '../publishing/protection.js';
import { bodyHash } from '../utils/bodyHash.js';

// Re-exported so existing callers/tests keep reading the list from this
// module; the definition lives in backend/publishing/protection.js.
export { PROTECTED_TEST_ARTICLES };

/**
 * Protected test articles — the owner's standing order (2026-11-19/20):
 * articles #26 and #27 are verification test artifacts whose content must
 * never be overwritten. The automatic daily workflow must never SELECT
 * them for a step that modifies an article (SEO repair, correction).
 * Manual per-article actions (an explicit dashboard/API call on one
 * article, e.g. runSeo / runFactChecking for a named article_id) are NOT
 * blocked — only the automatic draft selection below.
 * Fact-checking is advisory only (it never writes the body) and content
 * generation creates new articles, so neither needs this guard.
 * The list + the SQL exclusion helper live in
 * backend/publishing/protection.js (DB flag is_protected is the source
 * of truth, the constant is the fallback); this module re-exports the
 * list above and uses the imported helper at the correctionRun/seoRun
 * guard sites.
 */

export function todayStr(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

/**
 * The Worker's own public URL (Fix Pass 4 F1) — the daily run calls
 * the internal health-report route on it, so the five external-fetch
 * checks run in their own Worker invocation with a fresh
 * 50-subrequest budget. Hard-coded following the same precedent as
 * backend/social/oauth.js:104 (the workers.dev URL is the Worker's
 * stable public address; there is no env var for it).
 */
export const WORKER_BASE_URL = 'https://fs-ai.mdalfahad841.workers.dev';

/** Safety valve on the single internal-route call: the route's five
 * checks each carry a 10 s per-fetch timeout, so a hung route is cut
 * off here and the builder falls back to the in-process checks. */
export const HEALTH_REPORT_EXTERNAL_TIMEOUT_MS = 60 * 1000;

/**
 * Call the internal health-report route exactly once (Fix Pass 4 F1)
 * and return its checks map, or null when the route is unavailable
 * for any reason (no SESSION_SECRET configured, network error,
 * non-200, unparseable body, wrong shape). The caller treats null as
 * "route unavailable" and falls back to the in-process checks — a
 * fetch failure is still reported as FAIL there, never OK.
 *
 * Auth: the request is HMAC-signed with env.SESSION_SECRET (see
 * backend/security/crypto.js signInternalRequest) — the daily run is
 * a cron invocation and holds no owner session, so it cannot present
 * a requireOwner Bearer token. The signature covers method + path +
 * timestamp; the timestamp is the same nowMs the report is built
 * with, so the signed instant and the report instant agree.
 */
export async function fetchExternalHealthChecks(env, {
  fetchImpl = fetch,
  nowMs = Date.now(),
  workerBaseUrl = WORKER_BASE_URL,
} = {}) {
  const secret = env && typeof env.SESSION_SECRET === 'string' ? env.SESSION_SECRET : '';
  if (!secret) return null;
  const timestamp = String(nowMs);
  let signature = '';
  try {
    signature = await signInternalRequest(secret, 'POST', HEALTH_REPORT_EXTERNAL_PATH, timestamp);
  } catch {
    return null;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HEALTH_REPORT_EXTERNAL_TIMEOUT_MS);
  try {
    const res = await fetchImpl(`${workerBaseUrl}${HEALTH_REPORT_EXTERNAL_PATH}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-FS-AI-Internal-Timestamp': timestamp,
        'X-FS-AI-Internal-Signature': signature,
      },
      body: JSON.stringify({}),
      signal: controller.signal,
    });
    if (!res || res.status !== 200) return null;
    let data = null;
    try {
      data = JSON.parse(await res.text());
    } catch {
      return null;
    }
    if (!data || typeof data !== 'object' || data.ok !== true
      || typeof data.checks !== 'object' || data.checks === null) return null;
    return data.checks;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function plusMinutes(baseIso, minutes) {
  return new Date(new Date(baseIso).getTime() + minutes * 60 * 1000).toISOString();
}

// ---------------------------------------------------------------------
// Phase 4 (2026-11-20) — run lease + stale-lock recovery + cancel.
// Live Phase 3 finding: a long synchronous manual run dies mid-flight
// after ~4-5 minutes with no error, no save, no agent_runs row, and
// the task left 'running' forever (task #32 stuck twice with 0 LLM
// calls; re-check probes died after 3 and 5 judge calls; task #31
// orphaned since the Phase 2 era). Root cause: runTask claimed
// queued -> running and then awaited runAutonomyTask with no timeout,
// no lease and no try/finally, and generateWithWorkersAI awaited
// env.AI.run with no timeout. The fixes:
//   - TASK_RUN_LEASE_MS: a run that exceeds its lease fails with a
//     clear reason and its status is ALWAYS resolved (try/finally in
//     runTask) — a run ends done/failed/skipped, never stuck running.
//   - recoverStaleTasks(): 'running' tasks older than the lease are
//     recovered (reason 'stale-lock'): re-queued automatically with
//     backoff while attempts remain, so the next drain retries them
//     without a manual retry (self-healing per the owner zero-failure
//     brief, 2026-11-21 — the pre-W1 behaviour of leaving them 'failed'
//     for a manual retry is superseded); only when attempts are
//     exhausted do they go 'failed' with FAILED_FINAL_WITH_RECOVERY_REPORT.
//     Called by the dashboard endpoint and by the daily/weekly workflows
//     (best-effort, never blocking).
//   - cancelTask(): the owner can cancel a 'running' task; it lands
//     in 'failed' (reason 'cancelled-by-owner') and is retryable.
//   - A second run on a fresh 'running' task answers in-flight
//     (202-shape) instead of 409; a stale one is recovered first.
// No migration needed: only the existing status/updated_at columns
// and agent_runs rows are used. The lease cannot abort an in-flight
// AI call (the binding takes no signal) — it resolves the TASK state;
// in Workers the abandoned execution is killed when the request ends.
// ---------------------------------------------------------------------

/** A single task run may take at most 10 minutes before it is failed. */
export const TASK_RUN_LEASE_MS = 10 * 60 * 1000;

/**
 * Queue drain bounds (W1, 2026-11-21): at most this many queued tasks
 * per daily run, and the drain stops after this many consecutive
 * failures so one broken handler cannot burn the whole run.
 */
export const MAX_DRAIN_TASKS_PER_RUN = 10;
export const MAX_DRAIN_CONSECUTIVE_FAILURES = 3;

/** Backoff cap: a re-queued task never waits longer than 4 hours. */
export const DRAIN_BACKOFF_CAP_MINUTES = 240;

// ---------------------------------------------------------------------
// Task lifecycle — terminal states (W1, 2026-11-21; migration 020).
// Every task must reach exactly one terminal state; the five states
// live in agent_tasks.terminal_state (the legacy status column and its
// CHECK are untouched). History is never deleted: agent_runs /
// agent_logs keep every attempt. A FAILED_FINAL task stays visible and
// is never retried automatically — only an explicit owner retryTask()
// clears the terminal state and re-queues it.
// ---------------------------------------------------------------------

/** The five terminal states a task can end in. */
export const TERMINAL_STATES = [
  'COMPLETED',
  'RETRYING',
  'WAITING_FOR_AUTHORIZATION',
  'BLOCKED_WITH_REASON',
  'FAILED_FINAL_WITH_RECOVERY_REPORT',
];

/**
 * Retry backoff in minutes: 15 * 2^(attempts-1), capped at 4 hours.
 * Attempts 1-2 give 15/30 minutes — identical to the pre-W1 linear
 * attempts*15 schedule — so existing retry timing is preserved.
 */
export function backoffMinutesForAttempt(attempts) {
  const n = Number.isFinite(Number(attempts)) && Number(attempts) >= 1 ? Math.floor(Number(attempts)) : 1;
  return Math.min(15 * (2 ** (n - 1)), DRAIN_BACKOFF_CAP_MINUTES);
}

/**
 * True when a failure is permanent — retrying the same task the same
 * way can never succeed. Deliberately narrow: only errors that prove
 * the TASK itself is un-runnable (no handler exists for its agent, or
 * its payload is malformed). A missing article, a failed fetch, an LLM
 * quota error, or any handler error is TEMPORARY: the task re-queues
 * with backoff (the existing retry test pins "Article 99999 not
 * found" as retryable, so 'not found' is NOT permanent here).
 */
export function isPermanentTaskError(error) {
  const text = String(error || '');
  return /^Unknown autonomy agent:/i.test(text)
    || /needs a valid (article_id|division|payload)/i.test(text)
    || /invalid (payload|article_id|division|task)/i.test(text);
}

/**
 * The failure alert / recovery report written into the agent_runs
 * detail when a task reaches FAILED_FINAL (or is blocked permanently).
 * Every failure record carries: task id, component, root cause,
 * timestamp, retry history, recovery action, owner-action-required.
 */
export function buildRecoveryReport(task, result, attempts) {
  const error = String((result && result.error) || 'unknown error').slice(0, 300);
  const maxAttempts = (task && task.max_attempts) || 3;
  const exhausted = attempts >= maxAttempts;
  return {
    taskId: task ? task.id : null,
    component: task ? task.agent : null,
    kind: task ? task.kind : null,
    rootCause: error,
    timestamp: nowIso(),
    retryHistory: { attempts, maxAttempts, exhausted },
    recoveryAction: exhausted
      ? `Retries exhausted (${attempts}/${maxAttempts}) — the task will not auto-retry. Fix the cause, then retry it from the dashboard (retryTask resets attempts to 0).`
      : 'Permanent failure — fix the task payload or agent configuration, then retry it from the dashboard.',
    ownerActionRequired: true,
  };
}

/**
 * Best-effort terminal-state write (migration 020 columns). Silently
 * no-ops on a pre-020 database (missing-column error) and on any other
 * write failure — the legacy status column is always the source of
 * truth for the task's status, so a terminal-state write must never
 * break runTask / retryTask.
 */
export async function setTerminalState(env, taskId, state, reason = null, lastError = null) {
  if (!env || !env.DB) return false;
  if (state !== null && !TERMINAL_STATES.includes(state)) return false;
  try {
    await d1Run(env,
      'UPDATE agent_tasks SET terminal_state = ?, terminal_reason = ?, last_error = ?, updated_at = ? WHERE id = ?',
      [state, reason ? String(reason).slice(0, 500) : null, lastError ? String(lastError).slice(0, 500) : null, nowIso(), taskId]);
    return true;
  } catch (err) {
    if (isMissingColumnError(err)) return false;
    return false;
  }
}

/** Clear the terminal state on an explicit owner retry (retryTask). */
export async function clearTerminalState(env, taskId) {
  return setTerminalState(env, taskId, null, null, null);
}

/**
 * Articles created today (UTC) — the daily-content GENERATION cap counts
 * these. This is the ONE shared rule: it delegates to
 * articlesCreatedToday in backend/agents/autonomy/content.js, the single
 * definition — created today AND not already published on an earlier
 * date (a draft, or an article published today, counts; a seeded/live
 * article created today but published on an earlier date does not).
 * Fail-open: a lookup error returns 0 (the handler's version throws;
 * the drain must never throw on a counting error). This is the
 * GENERATION cap count (UTC day) and is intentionally separate from
 * the PUBLISH cap in backend/publishing/gate.js
 * (countPublishedTodayDhaka), which counts articles published today
 * on the Dhaka day — a different quantity.
 */
export async function countArticlesCreatedToday(env) {
  try {
    return await articlesCreatedToday(env);
  } catch {
    return 0;
  }
}

/**
 * Parse a D1/SQLite timestamp to epoch ms. D1 rows written by nowIso()
 * are ISO with 'T' + 'Z'; SQLite DEFAULT (datetime('now')) rows are
 * space-format 'YYYY-MM-DD HH:MM:SS' (UTC). Both read as UTC. Returns
 * null when the value cannot be parsed (never throws).
 */
export function parseDbTime(value) {
  if (typeof value !== 'string' || !value.trim()) return null;
  let text = value.trim();
  if (text.includes(' ')) text = text.replace(' ', 'T');
  if (!/[zZ]$/.test(text) && !/[+-]\d{2}:?\d{2}$/.test(text)) text += 'Z';
  const ms = Date.parse(text);
  return Number.isFinite(ms) ? ms : null;
}

/** True when a task has been 'running' longer than the lease. */
export function isTaskStale(task, leaseMs = TASK_RUN_LEASE_MS, nowMs = Date.now()) {
  if (!task || task.status !== 'running') return false;
  const started = parseDbTime(task.updated_at);
  if (started === null) return false; // unprovable — never guess stale
  return nowMs - started > leaseMs;
}

/** Race a promise against the run lease; on timeout resolve a failed result. */
function runWithLease(promise, leaseMs) {
  let timer = null;
  const timeout = new Promise((resolve) => {
    timer = setTimeout(() => resolve({ __leaseTimeout: true }), leaseMs);
  });
  return Promise.race([promise, timeout]).then(
    (value) => {
      if (timer) clearTimeout(timer);
      if (value && value.__leaseTimeout) {
        return {
          outcome: 'failed',
          error: `Task exceeded its run lease of ${Math.round(leaseMs / 1000)}s — the run was still in progress and was stopped; the task was marked failed so it can be retried.`,
        };
      }
      return value;
    },
    (err) => { if (timer) clearTimeout(timer); throw err; },
  );
}

/**
 * Recover ONE stale 'running' task: write a failed agent_runs row
 * (detail reason 'stale-lock'), then — self-healing per the owner
 * zero-failure brief (2026-11-21) — RE-QUEUE it automatically with
 * backoff while attempts remain, so a Worker restart recovers
 * without a manual retry. Only when attempts are exhausted does it
 * go 'failed' with FAILED_FINAL_WITH_RECOVERY_REPORT. Returns
 * { ok, recovered, taskId, ... } — recovered:false when the task is
 * not stale (fresh running, or any other status).
 */
export async function recoverStaleTask(env, taskId, { leaseMs = TASK_RUN_LEASE_MS, nowMs = Date.now() } = {}) {
  if (!env || !env.DB) return { ok: false, status: 503, error: 'D1 database is not bound.' };
  const id = Number(taskId);
  if (!Number.isInteger(id) || id <= 0) return { ok: false, status: 400, error: 'Task id must be a positive integer.' };
  const row = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [id]);
  if (!row) return { ok: false, status: 404, error: 'Task not found.' };
  const task = normaliseTaskRow(row);
  if (!isTaskStale(task, leaseMs, nowMs)) {
    return { ok: true, recovered: false, taskId: id, status: task.status, reason: 'not-stale' };
  }
  const staleForMs = nowMs - (parseDbTime(task.updated_at) || nowMs);
  const finalFailure = (task.attempts || 0) >= (task.max_attempts || 3);
  const recoveryReport = finalFailure
    ? buildRecoveryReport(task, { error: `Task ran longer than the ${Math.round(leaseMs / 1000)}s lease with no update (stale lock).` }, task.attempts || 0)
    : null;
  await writeRun(env, {
    taskId: id, agent: task.agent, outcome: 'failed',
    detail: { reason: 'stale-lock', staleForMs, updatedAt: task.updated_at, leaseMs, ...(recoveryReport ? { recoveryReport } : {}) },
    logs: [{ level: 'error', message: `Task ${id} (${task.agent}) recovered from a stale lock: running for ${Math.round(staleForMs / 1000)}s with no update (lease ${Math.round(leaseMs / 1000)}s).${finalFailure ? ' Retries exhausted — final failure.' : ' Re-queued with backoff so the next drain retries it automatically.'}` }],
  });
  if (finalFailure) {
    await d1Run(env, "UPDATE agent_tasks SET status = 'failed', updated_at = ? WHERE id = ?", [nowIso(), id]);
  } else {
    // Self-healing (owner zero-failure brief 2026-11-21): a stale lock
    // with attempts left RE-QUEUES automatically with the same
    // exponential backoff as a failed run — the next drain picks it up
    // once the backoff elapses. The task is never left 'failed'
    // waiting for a manual retry.
    const backoffUntil = new Date(nowMs + backoffMinutesForAttempt(task.attempts || 0) * 60000).toISOString();
    await d1Run(env, 'UPDATE agent_tasks SET status = ?, scheduled_for = ?, updated_at = ? WHERE id = ?',
      ['queued', backoffUntil, nowIso(), id]);
  }
  // Terminal state: a stale lock is retryable while attempts remain
  // (RETRYING); once attempts are exhausted it is final, with the
  // recovery report in the run detail above.
  await setTerminalState(env, id,
    finalFailure ? 'FAILED_FINAL_WITH_RECOVERY_REPORT' : 'RETRYING',
    finalFailure ? 'Stale lock with retries exhausted.' : 'Stale lock recovered — re-queued with backoff for automatic retry.',
    `Stale lock: running for ${Math.round(staleForMs / 1000)}s with no update.`);
  return { ok: true, recovered: true, taskId: id, agent: task.agent, staleForMs };
}

/**
 * Sweep every 'running' task and recover the stale ones. Never throws
 * for a single bad row — one failure is skipped, the rest still run.
 * Returns { ok, recovered: [{taskId, agent, staleForMs, updatedAt}],
 * skipped: [ids], count }.
 */
export async function recoverStaleTasks(env, { leaseMs = TASK_RUN_LEASE_MS, nowMs = Date.now() } = {}) {
  if (!env || !env.DB) return { ok: false, status: 503, error: 'D1 database is not bound.' };
  const rows = await d1All(env, "SELECT * FROM agent_tasks WHERE status = 'running' ORDER BY updated_at ASC") || [];
  const recovered = [];
  const skipped = [];
  for (const row of rows) {
    const task = normaliseTaskRow(row);
    if (!isTaskStale(task, leaseMs, nowMs)) { skipped.push(task.id); continue; }
    try {
      const res = await recoverStaleTask(env, task.id, { leaseMs, nowMs });
      if (res.recovered) recovered.push({ taskId: task.id, agent: task.agent, staleForMs: res.staleForMs, updatedAt: task.updated_at });
      else skipped.push(task.id);
    } catch {
      skipped.push(task.id);
    }
  }
  return { ok: true, recovered, skipped, count: recovered.length };
}

/**
 * Cancel a 'running' task. It lands in 'failed' with a 'cancelled-
 * by-owner' run row, so the existing retry endpoint can re-queue it.
 * Only running tasks can be cancelled; anything else is a 409. This
 * flips the row only — it cannot stop an execution already in flight
 * in another request (no handle exists on it); runTask's final status
 * write is conditional on still-'running', so a late completion never
 * resurrects a cancelled task.
 */
export async function cancelTask(env, taskId) {
  if (!env || !env.DB) return { ok: false, status: 503, error: 'D1 database is not bound.' };
  const id = Number(taskId);
  if (!Number.isInteger(id) || id <= 0) return { ok: false, status: 400, error: 'Task id must be a positive integer.' };
  const row = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [id]);
  if (!row) return { ok: false, status: 404, error: 'Task not found.' };
  const task = normaliseTaskRow(row);
  if (task.status !== 'running') {
    return { ok: false, status: 409, error: `Task is '${task.status}' — only running tasks can be cancelled.` };
  }
  await writeRun(env, {
    taskId: id, agent: task.agent, outcome: 'failed',
    detail: { reason: 'cancelled-by-owner', cancelledAt: nowIso() },
    logs: [{ level: 'warn', message: `Task ${id} (${task.agent}) cancelled by the owner while running — marked failed so it can be retried.` }],
  });
  await d1Run(env, "UPDATE agent_tasks SET status = 'failed', updated_at = ? WHERE id = ?", [nowIso(), id]);
  await setTerminalState(env, id, 'BLOCKED_WITH_REASON', 'Cancelled by the owner — owner action required to retry.', 'Cancelled by the owner while running.');
  return { ok: true, taskId: id, agent: task.agent, status: 'failed', cancelled: true };
}

async function writeRun(env, { taskId = null, agent, outcome, detail = {}, logs = [] }) {
  let runId = null;
  try {
    const now = nowIso();
    const result = await d1Run(env,
      'INSERT INTO agent_runs (task_id, agent, started_at, finished_at, outcome, detail) VALUES (?, ?, ?, ?, ?, ?)',
      [taskId, agent, now, now, outcome, JSON.stringify(detail)]);
    runId = result && result.meta ? result.meta.last_row_id : null;
    for (const log of logs) {
      const level = log.level === 'warn' || log.level === 'error' ? log.level : 'info';
      await d1Run(env,
        'INSERT INTO agent_logs (run_id, level, message, created_at) VALUES (?, ?, ?, ?)',
        [runId, level, String(log.message || '').slice(0, 1000), nowIso()]).catch(() => {});
    }
  } catch {
    runId = null;
  }
  return runId;
}

async function logSkip(env, agent, reason) {
  await writeRun(env, {
    taskId: null, agent, outcome: 'skipped',
    detail: { reason }, logs: [{ level: 'info', message: `Skipped: ${reason}` }],
  });
}

/**
 * Enqueue a task. Never duplicates: an existing row with the same
 * idempotency_key is returned as { task, duplicate: true }.
 *
 * Content-task exception (Fix 8, 2026-11-20): re-creating a content task
 * with the same key (same title, same day) used to silently drop the
 * newly supplied sources. The duplicate is still reused — one task,
 * history preserved — but valid new source URLs are merged into the
 * existing task's payload (see mergeContentTaskSources), so the content
 * run, which re-reads the task row, sees every source.
 *
 * Manual re-enqueue exception (live #33, 2026-11-22): when
 * `requeueTerminal` is set (manual dashboard enqueue only — scheduled
 * callers never pass it), a duplicate whose row is terminal
 * (done/failed/skipped) is re-queued for the requested work instead of
 * being returned dead. Queued/running duplicates are still returned
 * unchanged, and content tasks keep the Fix 8 merge path.
 */
const CONTENT_TASK_SOURCE_LIMIT = 10; // matches the dashboard's 10-source cap

function normaliseTitle(value) {
  return typeof value === 'string' ? value.trim().toLowerCase().replace(/\s+/g, ' ') : '';
}

function normaliseDivision(value) {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

// Dedupe key for a source URL: lowercase scheme+host, no fragment, no
// trailing slash. The STORED value is always the caller's original
// (trimmed) URL — resolveEvidence matches sources against
// research_items.url by exact string, so the stored text must not be
// rewritten.
function normaliseSourceUrl(raw) {
  if (typeof raw !== 'string') return null;
  const text = raw.trim();
  if (!text) return null;
  let parsed;
  try { parsed = new URL(text); } catch { return null; }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
  const path = parsed.pathname.replace(/\/+$/, '') || '/';
  return `${parsed.protocol}//${parsed.hostname.toLowerCase()}${parsed.port ? `:${parsed.port}` : ''}${path}${parsed.search}`;
}

// Merge a duplicate content-task creation's sources into the existing
// task. Returns null when the existing task is not a content task (the
// caller then returns the plain duplicate). Otherwise returns
// { task, sourceMerge } where task is the (possibly updated) task row
// and sourceMerge is one of:
//   existing-reused — no new sources were supplied
//   sources-added   — new valid sources were merged (listed in `added`)
//   no-new-sources  — sources were supplied but every one is a duplicate
//   rejected        — no source could be merged (invalid or mismatched;
//                     each entry in `rejected` carries its reason)
// A source is rejected when it is not a valid http(s) URL, when the
// re-creation names a different title/division than the original task
// (a source from another title/division must never mix in), or when the
// 10-source cap is already reached. The original task row is never
// deleted or recreated; a merge only rewrites its payload + updated_at.
async function mergeContentTaskSources(env, existingRow, newPayload, newDivisionId) {
  const existing = normaliseTaskRow(existingRow);
  if (!existing || existing.agent !== 'content-creation') return null;
  const existingPayload = existing.payload && typeof existing.payload === 'object' ? existing.payload : {};
  const newSources = newPayload && Array.isArray(newPayload.sources) ? newPayload.sources : [];
  if (newSources.length === 0) {
    return { task: existing, sourceMerge: { status: 'existing-reused', added: [], duplicates: [], rejected: [] } };
  }
  // A task that already ran (done / running / skipped) can never use
  // merged sources — its article was already converted (or it will
  // never run). Reject the merge instead of claiming 'sources-added'
  // for sources that reach nothing. Failed tasks may still merge: a
  // retry re-reads the payload at run time.
  if (existing.status === 'done' || existing.status === 'running' || existing.status === 'skipped') {
    const reason = `task already ${existing.status} — sources cannot reach the already-converted (or never-run) article; create a new task`;
    return {
      task: existing,
      sourceMerge: { status: 'rejected', added: [], duplicates: [], rejected: newSources.map((s) => ({ source: typeof s === 'string' ? s.trim() : '', reason })) },
    };
  }
  // Request-level guard: a re-creation for a different title/division
  // must never mix its sources into this task.
  const mismatchReasons = [];
  if (newPayload && typeof newPayload.title === 'string' && newPayload.title.trim()
    && normaliseTitle(newPayload.title) !== normaliseTitle(existingPayload.title)) {
    mismatchReasons.push(`title does not match the original task ("${String(existingPayload.title || '').trim()}")`);
  }
  if (newPayload && typeof newPayload.division === 'string' && newPayload.division.trim()
    && normaliseDivision(newPayload.division) !== normaliseDivision(existingPayload.division)) {
    mismatchReasons.push(`division does not match the original task ("${String(existingPayload.division || '').trim()}")`);
  }
  if (newDivisionId != null && existing.division_id != null && Number(newDivisionId) !== Number(existing.division_id)) {
    mismatchReasons.push('division_id does not match the original task');
  }
  const supplied = newSources.map((s) => (typeof s === 'string' ? s.trim() : ''));
  if (mismatchReasons.length > 0) {
    const reason = `mismatched re-creation: ${mismatchReasons.join('; ')}`;
    return {
      task: existing,
      sourceMerge: { status: 'rejected', added: [], duplicates: [], rejected: supplied.map((s) => ({ source: s, reason })) },
    };
  }
  const existingSources = (Array.isArray(existingPayload.sources) ? existingPayload.sources : [])
    .filter((s) => typeof s === 'string' && s.trim()).map((s) => s.trim());
  const seenKeys = new Set(existingSources.map((s) => normaliseSourceUrl(s)).filter(Boolean));
  const seenExact = new Set(existingSources);
  const added = [];
  const duplicates = [];
  const rejected = [];
  const mergedSources = [...existingSources];
  for (const text of supplied) {
    if (!text) { rejected.push({ source: text, reason: 'empty source' }); continue; }
    const key = normaliseSourceUrl(text);
    if (!key) { rejected.push({ source: text, reason: 'not a valid http(s) URL' }); continue; }
    if (seenKeys.has(key) || seenExact.has(text)) { duplicates.push(text); continue; }
    if (mergedSources.length >= CONTENT_TASK_SOURCE_LIMIT) {
      rejected.push({ source: text, reason: `source limit of ${CONTENT_TASK_SOURCE_LIMIT} reached` });
      continue;
    }
    seenKeys.add(key);
    seenExact.add(text);
    mergedSources.push(text);
    added.push(text);
  }
  const status = added.length > 0 ? 'sources-added' : (rejected.length > 0 ? 'rejected' : 'no-new-sources');
  if (added.length === 0) {
    return { task: existing, sourceMerge: { status, added, duplicates, rejected } };
  }
  const now = nowIso();
  const nextPayload = { ...existingPayload, sources: mergedSources };
  await d1Run(env, 'UPDATE agent_tasks SET payload = ?, updated_at = ? WHERE id = ?',
    [JSON.stringify(nextPayload), now, existing.id]);
  const row = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [existing.id]);
  const task = row ? normaliseTaskRow(row) : { ...existing, payload: nextPayload, updated_at: now };
  return { task, sourceMerge: { status, added, duplicates, rejected } };
}

// Shared duplicate return: a content task gets its sources merged
// (Fix 8); every other task returns the existing row unchanged —
// UNLESS the caller is a manual dashboard re-enqueue (requeueTerminal)
// and the existing row is terminal (done/failed/skipped). Live #33,
// 2026-11-22: the dashboard Correct button re-uses the dated key
// `manual-correct-<id>-<date>`, so a second same-day click returned the
// finished task #44 unchanged ("already existed — run it from the task
// queue") — but a 'done' task has no Run button and Retry renders only
// for 'failed', so the correction could never be retried. A manual
// re-enqueue re-queues the terminal row for the requested work instead:
// status queued, kind + payload restored to the request, attempts reset
// to 0 (the explicit-owner-retry precedent from retryTask) and the
// terminal state cleared, so the task can reach a fresh terminal state.
// Queued/running rows are never touched (genuine double-click
// protection), content tasks keep the Fix 8 merge path, and scheduled
// callers never pass the flag, so a completed daily task is never
// re-run by a second daily-run pass.
async function duplicateTaskResult(env, row, payload, division_id, opts = {}) {
  const merged = await mergeContentTaskSources(env, row, payload || {}, division_id);
  if (merged) return { ok: true, task: merged.task, duplicate: true, sourceMerge: merged.sourceMerge };
  const existing = normaliseTaskRow(row);
  if (opts.requeueTerminal && ['done', 'failed', 'skipped'].includes(existing.status)) {
    const now = nowIso();
    await d1Run(env,
      "UPDATE agent_tasks SET agent = ?, kind = ?, payload = ?, division_id = ?, priority = ?, status = 'queued', attempts = 0, scheduled_for = ?, updated_at = ? WHERE id = ?",
      [opts.agent, opts.kind, JSON.stringify(payload || {}), division_id, opts.priority ?? 5, opts.scheduled_for ?? null, now, existing.id]);
    // Explicit owner retry is the ONLY reset: clear the old terminal
    // state so the re-queued task can reach a fresh terminal state.
    await clearTerminalState(env, existing.id);
    const fresh = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [existing.id]);
    return { ok: true, task: normaliseTaskRow(fresh || existing), duplicate: true, requeued: true };
  }
  return { ok: true, task: existing, duplicate: true };
}

export async function enqueueTask(env, { agent, kind, payload = {}, division_id = null, priority = 5, idempotency_key, scheduled_for = null, requeueTerminal = false }) {
  if (!env || !env.DB) return { ok: false, status: 503, error: 'D1 database is not bound.' };
  if (!agent || typeof agent !== 'string') return { ok: false, status: 400, error: 'agent is required.' };
  if (!kind || typeof kind !== 'string') return { ok: false, status: 400, error: 'kind is required.' };
  const key = idempotency_key || `manual-${agent}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const existing = await d1First(env, 'SELECT * FROM agent_tasks WHERE idempotency_key = ? LIMIT 1', [key]);
  if (existing) return duplicateTaskResult(env, existing, payload, division_id, { requeueTerminal, agent, kind, priority, scheduled_for });
  const now = nowIso();
  try {
    const result = await d1Run(env,
      'INSERT INTO agent_tasks (agent, kind, payload, division_id, priority, status, attempts, max_attempts, idempotency_key, scheduled_for, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [agent, kind, JSON.stringify(payload || {}), division_id, priority, 'queued', 0, 3, key, scheduled_for, now, now]);
    const id = result && result.meta ? result.meta.last_row_id : null;
    const row = id ? await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [id]) : null;
    return { ok: true, task: normaliseTaskRow(row || { id, agent, kind, payload: JSON.stringify(payload || {}), division_id, priority, status: 'queued', attempts: 0, max_attempts: 3, idempotency_key: key, scheduled_for, created_at: now, updated_at: now }), duplicate: false };
  } catch (err) {
    // Race on the UNIQUE key: re-read and return the existing row.
    if (/UNIQUE|unique/i.test(String(err && err.message ? err.message : ''))) {
      const row = await d1First(env, 'SELECT * FROM agent_tasks WHERE idempotency_key = ? LIMIT 1', [key]);
      if (row) return duplicateTaskResult(env, row, payload, division_id, { requeueTerminal, agent, kind, priority, scheduled_for });
    }
    return { ok: false, status: 500, error: String(err && err.message ? err.message : err).slice(0, 200) };
  }
}

export function normaliseTaskRow(row) {
  if (!row) return null;
  let payload = row.payload;
  try { payload = typeof payload === 'string' ? JSON.parse(payload) : (payload || {}); } catch { payload = {}; }
  return { ...row, payload };
}

async function registryStatus(env, registryId) {
  if (!registryId || !env || !env.DB) return null;
  try {
    const row = await d1First(env,
      'SELECT status, is_active FROM ai_agents WHERE slug = ? OR name = ? LIMIT 1', [registryId, registryId]);
    if (!row) return null;
    if (typeof row.status === 'string' && row.status) return row.status;
    return row.is_active ? 'active' : 'disabled';
  } catch {
    return null;
  }
}

/**
 * Result for runTask() when the task is not 'queued' at the moment of
 * the call. A fresh 'running' task answers in-flight (202-shape);
 * a stale one is recovered to 'failed' first; anything else is a 409.
 * Shared by the pre-claim check and by a lost conditional claim (the
 * race path), so both agree on the outcome.
 */
async function handleNonQueuedRun(env, task, leaseMs) {
  if (task.status === 'running') {
    // Phase 4: a stale lock heals itself — recover it and tell the
    // caller to retry; a genuinely in-flight run answers in-flight
    // (the HTTP layer maps it to 202), never a 409.
    if (isTaskStale(task, leaseMs)) {
      const recovered = await recoverStaleTask(env, task.id, { leaseMs });
      if (recovered.recovered) {
        return {
          ok: false, status: 409, recoveredStale: true, taskId: task.id,
          error: `Task was stuck 'running' with no update for over ${Math.round(leaseMs / 60000)} minute(s) — recovered and re-queued with backoff, so the next drain retries it automatically once the backoff elapses.`,
        };
      }
    }
    return { ok: true, inFlight: true, taskId: task.id, status: 'running', attempts: task.attempts, updatedAt: task.updated_at };
  }
  return { ok: false, status: 409, error: `Task is '${task.status}' — only queued tasks can run.` };
}

/**
 * Set status='skipped' only while the task is still 'queued' (a
 * concurrent claim must win over a skip — a running task is never
 * flipped to skipped). Returns true when this call made the skip.
 */
async function markSkippedIfQueued(env, taskId) {
  const r = await d1Run(env,
    "UPDATE agent_tasks SET status = 'skipped', updated_at = ? WHERE id = ? AND status = 'queued'",
    [nowIso(), taskId]);
  return !!(r && r.meta && Number(r.meta.changes) === 1);
}

/**
 * Run one queued task now. Claims it (queued -> running, attempts+1),
 * checks Emergency Stop (423-style skip) and the mapped registry agent's
 * paused state, dispatches via runAutonomyTask, writes agent_runs +
 * agent_logs, and sets the task done/failed (failure with attempts left
 * re-queues with attempts*15-minute backoff).
 *
 * Phase 4 (2026-11-20) — the execution is raced against TASK_RUN_LEASE_MS
 * and the whole post-claim section runs in try/finally, so the task
 * status is ALWAYS resolved: a run ends done/failed/skipped, never
 * stuck 'running'. A second call on a fresh 'running' task returns
 * { ok: true, inFlight: true } (the caller maps it to 202) instead of
 * 409; a stale 'running' task is recovered to 'failed' first
 * (recoveredStale: true). The final status write is conditional on
 * still-'running', so a concurrent owner cancel is never overwritten
 * by a late completion (reported as cancelledDuringRun).
 * options.leaseMs overrides TASK_RUN_LEASE_MS (tests).
 */
export async function runTask(env, taskId, options = {}) {
  if (!env || !env.DB) return { ok: false, status: 503, error: 'D1 database is not bound.' };
  const id = Number(taskId);
  if (!Number.isInteger(id) || id <= 0) return { ok: false, status: 400, error: 'Task id must be a positive integer.' };
  const leaseMs = options && Number.isFinite(Number(options.leaseMs)) && Number(options.leaseMs) > 0
    ? Number(options.leaseMs) : TASK_RUN_LEASE_MS;
  const row = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [id]);
  if (!row) return { ok: false, status: 404, error: 'Task not found.' };
  const task = normaliseTaskRow(row);
  if (task.status !== 'queued') {
    return handleNonQueuedRun(env, task, leaseMs);
  }

  // Manual task runs must not bypass protection: a modifying task
  // (seo repair / correction) for a protected article is refused here,
  // before any status change or execution.
  const protection = await assertTaskNotProtected(env, task);
  if (!protection.ok) {
    return { ok: false, status: 403, error: protection.reason, protected: true };
  }

  if (await getEmergencyStop(env)) {
    if (await markSkippedIfQueued(env, id)) {
      await writeRun(env, {
        taskId: id, agent: task.agent, outcome: 'skipped',
        detail: { reason: 'Emergency Stop is on.' },
        logs: [{ level: 'warn', message: 'Task skipped: Emergency Stop is on.' }],
      });
      await setTerminalState(env, id, 'BLOCKED_WITH_REASON', 'Emergency Stop is on — owner action required to resume autonomous operations.', 'Emergency Stop is on.');
      return { ok: false, status: 423, error: 'Autonomous operations are stopped by Emergency Stop', skipped: true };
    }
    // A concurrent claim won the race while we checked: report the
    // live state instead of skipping a running task.
    const fresh = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [id]);
    return fresh ? handleNonQueuedRun(env, normaliseTaskRow(fresh), leaseMs)
      : { ok: false, status: 423, error: 'Autonomous operations are stopped by Emergency Stop', skipped: true };
  }

  // Pause check: the registry agent that governs this task. For research
  // this resolves through the division-slug -> agent map (a paused
  // division research agent makes that division's research tasks skip).
  // A division-less research task skips only when EVERY division
  // research agent is paused; an unknown registry state never blocks.
  const registryId = registryIdForTask(task);
  let pausedId = null;
  if (registryId) {
    const status = await registryStatus(env, registryId);
    if (status && status !== 'active') pausedId = registryId;
  } else if (task.agent === 'research') {
    const ids = Object.values(DIVISION_RESEARCH_REGISTRY);
    let allPaused = ids.length > 0;
    for (const id of ids) {
      const status = await registryStatus(env, id);
      if (!status || status === 'active') { allPaused = false; break; }
    }
    if (allPaused) pausedId = 'research (all division research agents)';
  }
  if (pausedId) {
    if (await markSkippedIfQueued(env, id)) {
      await writeRun(env, {
        taskId: id, agent: task.agent, outcome: 'skipped',
        detail: { reason: `Agent ${pausedId} is paused.` },
        logs: [{ level: 'warn', message: `Task skipped: agent ${pausedId} is paused.` }],
      });
      await setTerminalState(env, id, 'WAITING_FOR_AUTHORIZATION', `Agent ${pausedId} is paused — resume it before running.`, `Agent ${pausedId} is paused.`);
      return { ok: false, status: 409, error: `Agent ${pausedId} is paused — resume it before running.`, skipped: true };
    }
    const fresh = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [id]);
    return fresh ? handleNonQueuedRun(env, normaliseTaskRow(fresh), leaseMs)
      : { ok: false, status: 409, error: `Agent ${pausedId} is paused — resume it before running.`, skipped: true };
  }

  // Conditional claim (W1 fix for the read-then-UPDATE race): the row
  // flips to 'running' ONLY while it is still 'queued', in a single
  // UPDATE. When two runTask calls race, exactly one sees changes===1
  // and runs; the loser re-reads and answers in-flight / 409 instead
  // of running the task twice.
  const attempts = (task.attempts || 0) + 1;
  const claim = await d1Run(env,
    "UPDATE agent_tasks SET status = 'running', attempts = ?, updated_at = ? WHERE id = ? AND status = 'queued'",
    [attempts, nowIso(), id]);
  if (claim && claim.meta && Number(claim.meta.changes) === 0) {
    const fresh = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [id]);
    if (!fresh) return { ok: false, status: 404, error: 'Task not found.' };
    return handleNonQueuedRun(env, normaliseTaskRow(fresh), leaseMs);
  }

  const startedAt = nowIso();
  let result = null;
  let outcome = 'failed';
  let runId = null;
  let finishedAt = null;
  let requeued = false;
  let backoffUntil = null;
  let cancelledDuringRun = false;
  let terminalState = null;
  try {
    result = await runWithLease(runAutonomyTask(task, env), leaseMs);
    outcome = result && (result.outcome === 'done' || result.outcome === 'no-op') ? result.outcome : 'failed';
  } catch (err) {
    result = { outcome: 'failed', error: String(err && err.message ? err.message : err).slice(0, 300) };
    outcome = 'failed';
  } finally {
    // The status is resolved here, ALWAYS — even when the run-row
    // insert below throws. A run ends done/failed (or re-queued), never
    // stuck 'running'. The status writes are conditional on
    // still-'running': a concurrent owner cancel wins over a late
    // completion, so a cancelled task is never resurrected.
    finishedAt = nowIso();
    // Terminal-state inputs, computed BEFORE the run row is written so
    // a final failure carries its recovery report in the run detail.
    // A permanent error (no handler / malformed payload) never
    // re-queues: it is BLOCKED_WITH_REASON on the first attempt.
    const permanentError = outcome === 'failed' && isPermanentTaskError(result && result.error);
    const finalFailure = outcome === 'failed' && (permanentError || attempts >= (task.max_attempts || 3));
    terminalState = null;
    if (outcome !== 'failed') terminalState = 'COMPLETED';
    else if (permanentError) terminalState = 'BLOCKED_WITH_REASON';
    else if (finalFailure) terminalState = 'FAILED_FINAL_WITH_RECOVERY_REPORT';
    else terminalState = 'RETRYING';
    if (finalFailure && result && typeof result === 'object') {
      result = { ...result, recoveryReport: buildRecoveryReport(task, result, attempts) };
    }
    try {
      const inserted = await d1Run(env,
        'INSERT INTO agent_runs (task_id, agent, started_at, finished_at, outcome, detail) VALUES (?, ?, ?, ?, ?, ?)',
        [id, task.agent, startedAt, finishedAt, outcome, JSON.stringify(result || {})]);
      runId = inserted && inserted.meta ? inserted.meta.last_row_id : null;
      const logMessage = outcome === 'failed'
        ? `Task ${id} (${task.agent}) failed: ${String(result.error || 'unknown error').slice(0, 300)}`
        : `Task ${id} (${task.agent}) finished: ${outcome}.`;
      await d1Run(env, 'INSERT INTO agent_logs (run_id, level, message, created_at) VALUES (?, ?, ?, ?)',
        [runId, outcome === 'failed' ? 'error' : 'info', logMessage.slice(0, 1000), nowIso()]).catch(() => {});
    } catch {
      runId = null;
    }
    const resolveStatus = async () => {
      const errorText = outcome === 'failed' ? String((result && result.error) || 'unknown error').slice(0, 300) : null;
      if (outcome === 'failed' && !permanentError && attempts < (task.max_attempts || 3)) {
        backoffUntil = plusMinutes(finishedAt, backoffMinutesForAttempt(attempts));
        const r = await d1Run(env,
          "UPDATE agent_tasks SET status = 'queued', scheduled_for = ?, updated_at = ? WHERE id = ? AND status = 'running'",
          [backoffUntil, nowIso(), id]);
        if (r && r.meta && r.meta.changes === 0) { cancelledDuringRun = true; return; }
        requeued = true;
        await setTerminalState(env, id, 'RETRYING',
          `Attempt ${attempts} failed: ${errorText}; retry scheduled in ${backoffMinutesForAttempt(attempts)} minutes.`, errorText);
        return;
      }
      const finalStatus = outcome === 'failed' ? 'failed' : 'done';
      const r = await d1Run(env,
        "UPDATE agent_tasks SET status = ?, updated_at = ? WHERE id = ? AND status = 'running'",
        [finalStatus, nowIso(), id]);
      if (r && r.meta && r.meta.changes === 0) { cancelledDuringRun = true; return; }
      // Terminal state: done -> COMPLETED; permanent failure ->
      // BLOCKED_WITH_REASON (no retry); exhausted retries ->
      // FAILED_FINAL_WITH_RECOVERY_REPORT (report is in the run detail).
      const reason = outcome === 'failed'
        ? (permanentError
          ? `Permanent failure: ${errorText} — fix the task, then retry from the dashboard.`
          : `Retries exhausted (${attempts}/${task.max_attempts || 3}): ${errorText}`)
        : `Task finished: ${outcome}.`;
      await setTerminalState(env, id, terminalState, reason, errorText);
    };
    try {
      await resolveStatus();
    } catch {
      // One retry: the run row still records the outcome even if the
      // status write keeps failing.
      try { await resolveStatus(); } catch { /* status stays as claimed; the sweeper recovers it */ }
    }
  }
  return {
    ok: true, taskId: id, runId, outcome, attempts, requeued, terminalState,
    ...(requeued && backoffUntil ? { scheduled_for: backoffUntil } : {}),
    ...(cancelledDuringRun ? { cancelledDuringRun: true } : {}),
    result,
  };
}

/**
 * Safe retry of a failed task: resets it to queued with attempts 0 and
 * no backoff, so the next manual or scheduled run picks it up. Only
 * failed tasks can be retried; anything else is a 409. The caller
 * (orchestrator) enforces owner-only access.
 */
export async function retryTask(env, taskId) {
  if (!env || !env.DB) return { ok: false, status: 503, error: 'D1 database is not bound.' };
  const id = Number(taskId);
  if (!Number.isInteger(id) || id <= 0) return { ok: false, status: 400, error: 'Task id must be a positive integer.' };
  const row = await d1First(env, 'SELECT * FROM agent_tasks WHERE id = ? LIMIT 1', [id]);
  if (!row) return { ok: false, status: 404, error: 'Task not found.' };
  const task = normaliseTaskRow(row);
  if (task.status !== 'failed') {
    return { ok: false, status: 409, error: `Task is '${task.status}' — only failed tasks can be retried.` };
  }
  // A failed modifying task for a protected article must not re-queue.
  const protection = await assertTaskNotProtected(env, task);
  if (!protection.ok) {
    return { ok: false, status: 403, error: protection.reason, protected: true };
  }
  await d1Run(env, "UPDATE agent_tasks SET status = 'queued', attempts = 0, scheduled_for = NULL, updated_at = ? WHERE id = ?",
    [nowIso(), id]);
  // Explicit owner retry is the ONLY reset: the terminal state is
  // cleared so the task can reach a fresh terminal state.
  await clearTerminalState(env, id);
  await writeRun(env, {
    taskId: id, agent: task.agent, outcome: 'no-op',
    detail: { step: 'retry', reason: 'Owner retried a failed task.' },
    logs: [{ level: 'info', message: `Task ${id} (${task.agent}) retried by owner — back to queued.` }],
  });
  return { ok: true, taskId: id, agent: task.agent };
}

async function autonomySetting(env, key, fallback = 'off') {
  try {
    const row = await d1First(env, 'SELECT value FROM autonomy_settings WHERE key = ? LIMIT 1', [key]);
    return row && typeof row.value === 'string' ? row.value : fallback;
  } catch {
    return fallback;
  }
}

async function autoFlags(env) {
  const out = {};
  for (const k of ['auto_research', 'auto_generation', 'auto_factcheck', 'auto_correction', 'auto_publishing']) {
    out[k] = await autonomySetting(env, k, 'off');
  }
  return out;
}

async function maxArticlesPerDay(env) {
  const n = Number.parseInt(await autonomySetting(env, 'max_articles_per_day', '1'), 10);
  return Number.isFinite(n) && n >= 0 ? n : 1;
}

/**
 * Persist a drained content task's LLM draft as a CMS draft (WS-B,
 * 2026-11-21). runContentCreation returns its draft ONLY in the run
 * detail — no article row exists until convertScaffoldToDraft stores
 * it, and the only other caller is the manual dashboard convert
 * endpoint. Without this step the drain reported 'done' for a content
 * task while no article ever appeared: the task's output sat
 * un-persisted in agent_runs.detail. Only a completed LLM draft is
 * converted (outcome 'done' + scaffold.llmGenerated + a non-empty
 * body); 'no-op' scaffolds (insufficient evidence, LLM unavailable,
 * cap reached) are NEVER converted — converting them would mint empty
 * placeholder articles. A draft is always stored as status 'draft'
 * with fact_checked = 0, never published. A slug that already exists
 * (e.g. the owner converted the run manually first) is treated as
 * already-converted, never a duplicate. A conversion failure is
 * recorded here in an agent_runs row and in the drain result — it
 * never flips the already-COMPLETED task, and it never stops the
 * drain. Returns { converted, articleId?, alreadyConverted?, error? }.
 */
export async function convertContentDraft(env, task, scaffold) {
  const title = typeof scaffold.title === 'string' ? scaffold.title.trim() : '';
  const slug = slugify(title);
  if (!slug) {
    return { converted: false, error: 'Draft has no usable title — cannot derive a slug.' };
  }
  try {
    const existing = await d1First(env, 'SELECT id FROM articles WHERE slug = ? LIMIT 1', [slug]);
    if (existing) {
      return { converted: false, alreadyConverted: true, articleId: existing.id };
    }
  } catch {
    // A failed pre-check must not block the convert attempt itself.
  }
  const res = await convertScaffoldToDraft(env, scaffold);
  if (res && res.ok && res.article) {
    return { converted: true, articleId: res.article.id };
  }
  const error = String((res && res.error) || 'Draft could not be stored.').slice(0, 300);
  await writeRun(env, {
    taskId: task.id, agent: task.agent, outcome: 'failed',
    detail: { step: 'scaffold-convert', taskId: task.id, error },
    logs: [{ level: 'error', message: `Task ${task.id} (${task.agent}) finished, but its draft could not be stored as an article: ${error}` }],
  });
  return { converted: false, error };
}

// ---------------------------------------------------------------------
// Queue drain (W1, 2026-11-21).
// The daily workflow used to enqueue tasks and then do the same work
// inline without ever calling runTask, so the queue never drained
// (12 tasks queued, 0 running, 2026-11-21). drainTaskQueue is the
// missing step: it runs the health check first, then executes eligible
// queued tasks oldest-first through runTask — never runAutonomyTask
// directly, so the E-Stop check, paused-agent skip, protected-article
// guard, lease and terminal-state handling are all inherited.
// Rules:
//   - only status='queued' AND (scheduled_for IS NULL OR
//     scheduled_for <= now) — scheduled_for was write-only before.
//   - at most MAX_DRAIN_TASKS_PER_RUN (10) tasks ATTEMPTED per run.
//     Skipped tasks do not consume a slot: the drain pages past them
//     (cursor fetch, same order) until 10 tasks have been attempted or
//     the queue is exhausted, so more than 10 rows may be examined.
//   - stop after MAX_DRAIN_CONSECUTIVE_FAILURES (3) consecutive
//     failures; a success resets the counter.
//   - kinds with no handler (agent not in QUEUE_AGENTS) are skipped
//     and left queued, recorded with reason 'no-handler'.
//   - daily-content tasks obey the daily cap: articles created today
//     AND not already published on an earlier date are counted before
//     each content task (the same rule the content handler uses — see
//     countArticlesCreatedToday), and further content tasks are skipped
//     once maxArticlesPerDay is reached (the cap was previously
//     enforced only at enqueue time).
//   - a blocked health check (E-Stop ON, DB unreachable) refuses the
//     whole drain; 'degraded' proceeds and is recorded.
//   - an E-Stop that flips on mid-drain stops the drain at the next
//     task (runTask returns 423 for it).
// Returns { ok, blocked, health, results, processed, done, failed,
//   skipped, stoppedReason } where each result is { taskId, kind,
//   agent, outcome, attempts, requeued, reason? }.
// ---------------------------------------------------------------------
export async function drainTaskQueue(env, options = {}) {
  const maxTasks = Number.isFinite(Number(options.maxTasks)) && Number(options.maxTasks) > 0
    ? Math.floor(Number(options.maxTasks)) : MAX_DRAIN_TASKS_PER_RUN;
  const maxConsecutiveFailures = Number.isFinite(Number(options.maxConsecutiveFailures)) && Number(options.maxConsecutiveFailures) > 0
    ? Math.floor(Number(options.maxConsecutiveFailures)) : MAX_DRAIN_CONSECUTIVE_FAILURES;
  const leaseMs = options && Number.isFinite(Number(options.leaseMs)) && Number(options.leaseMs) > 0
    ? Number(options.leaseMs) : TASK_RUN_LEASE_MS;
  if (!env || !env.DB) return { ok: false, blocked: true, health: null, results: [], processed: 0, done: 0, failed: 0, skipped: 0, draftsConverted: 0, stoppedReason: 'no-database' };

  const health = await runHealthCheck(env);
  if (health.overall === 'blocked') {
    return { ok: false, blocked: true, health, results: [], processed: 0, done: 0, failed: 0, skipped: 0, draftsConverted: 0, stoppedReason: 'health-check-blocked' };
  }

  const dailyLimit = await maxArticlesPerDay(env);
  const results = [];
  let consecutiveFailures = 0;
  let stoppedReason = null;
  let done = 0;
  let failed = 0;
  let skipped = 0;
  let draftsConverted = 0;
  // B2 (O1): LIMIT-before-filtering — a skipped task used to consume a
  // drain slot, so eligible tasks behind it waited for the next run.
  // Page instead: keep fetching until maxTasks tasks have been
  // ATTEMPTED (runTask invoked) or the queue is exhausted. The first
  // fetch is exactly as before; later pages use a (created_at, id)
  // cursor on the same ORDER BY — row-value comparison keeps the
  // order exact where OFFSET would shift under the drain's own status
  // updates. agent_tasks.created_at is TEXT NOT NULL DEFAULT
  // (datetime('now')), so the initial cursor ('', 0) matches every row.
  let attempted = 0;
  let cursorCreatedAt = '';
  let cursorId = 0;
  let firstPage = true;

  pageLoop: while (attempted < maxTasks) {
    const pageLimit = firstPage ? maxTasks : maxTasks - attempted;
    let rows = [];
    try {
      if (firstPage) {
        rows = await d1All(env,
          "SELECT * FROM agent_tasks WHERE status = 'queued' AND (scheduled_for IS NULL OR scheduled_for <= ?) ORDER BY created_at ASC, id ASC LIMIT ?",
          [nowIso(), maxTasks]) || [];
        firstPage = false;
      } else {
        rows = await d1All(env,
          "SELECT * FROM agent_tasks WHERE status = 'queued' AND (scheduled_for IS NULL OR scheduled_for <= ?) AND (created_at, id) > (?, ?) ORDER BY created_at ASC, id ASC LIMIT ?",
          [nowIso(), cursorCreatedAt, cursorId, pageLimit]) || [];
      }
    } catch (err) {
      const reason = `queue-read-failed: ${String((err && err.message) || err).slice(0, 200)}`;
      if (results.length === 0) {
        return { ok: false, blocked: false, health, results: [], processed: 0, done: 0, failed: 0, skipped: 0, draftsConverted: 0, stoppedReason: reason };
      }
      // A later page failed after some work was done: work done is
      // work done — report the partial results with ok:true.
      stoppedReason = reason;
      break pageLoop;
    }
    if (rows.length === 0) break pageLoop;

    for (const raw of rows) {
      // Advance the cursor to the last examined row, whatever happens
      // to it below, so the next page never re-reads it.
      cursorCreatedAt = typeof raw.created_at === 'string' ? raw.created_at : '';
      cursorId = raw.id;
      if (consecutiveFailures >= maxConsecutiveFailures) {
        stoppedReason = 'consecutive-failure-limit';
        break pageLoop;
      }
      const task = normaliseTaskRow(raw);
      const base = { taskId: task.id, kind: task.kind, agent: task.agent, attempts: task.attempts || 0 };
      if (!QUEUE_AGENTS.includes(task.agent)) {
        skipped += 1;
        results.push({ ...base, outcome: 'skipped', reason: `No handler for agent '${task.agent}' — task left queued.` });
        continue;
      }
      if (task.agent === 'content-creation' && task.kind === 'daily-content') {
        const createdToday = await countArticlesCreatedToday(env);
        if (createdToday >= dailyLimit) {
          skipped += 1;
          results.push({ ...base, outcome: 'skipped', reason: `Daily content cap reached (${createdToday}/${dailyLimit} articles created today) — task left queued.` });
          continue;
        }
      }
      // Attempted the moment runTask is invoked: skips found only by
      // attempting (inFlight, recoveredStale, 409 refusals, E-Stop 423)
      // count as attempted — they were attempted.
      attempted += 1;
      let res;
      try {
        res = await runTask(env, task.id, { leaseMs });
      } catch (err) {
        res = { ok: false, outcome: 'failed', error: String((err && err.message) || err).slice(0, 300) };
      }
      if (res && res.status === 423) {
        // Emergency Stop flipped on mid-drain: stop now, record it.
        skipped += 1;
        results.push({ ...base, outcome: 'skipped', reason: 'Emergency Stop is on — drain stopped.' });
        stoppedReason = 'emergency-stop';
        break pageLoop;
      }
      if (res && res.inFlight) {
        skipped += 1;
        results.push({ ...base, outcome: 'skipped', reason: 'Task already running in another execution.' });
        continue;
      }
      if (res && res.recoveredStale) {
        skipped += 1;
        results.push({ ...base, outcome: 'skipped', reason: 'Task was recovered from a stale lock and re-queued with backoff — it runs automatically once the backoff elapses.' });
        continue;
      }
      if (!res || res.ok !== true) {
        // runTask refused without running (409 protection / pause /
        // already-resolved): a skip, not a drain failure.
        skipped += 1;
        results.push({ ...base, outcome: 'skipped', reason: String((res && res.error) || 'Task could not run.').slice(0, 300) });
        continue;
      }
      const outcome = res.outcome || 'failed';
      if (outcome === 'done' || outcome === 'no-op') {
        done += 1;
        consecutiveFailures = 0;
        // A drained content task that produced a real LLM draft must
        // persist it as a CMS draft now (see convertContentDraft) —
        // otherwise the drain reports 'done' and no article appears.
        // 'no-op' scaffolds are never converted.
        let conversion = null;
        if (outcome === 'done' && task.agent === 'content-creation' && res.result
          && res.result.scaffold && res.result.scaffold.llmGenerated
          && typeof res.result.scaffold.body === 'string' && res.result.scaffold.body.trim()) {
          try {
            conversion = await convertContentDraft(env, task, res.result.scaffold);
          } catch (err) {
            conversion = { converted: false, error: String((err && err.message) || err).slice(0, 300) };
          }
          if (conversion && conversion.converted) draftsConverted += 1;
        }
        results.push({ ...base, outcome, attempts: res.attempts, requeued: !!res.requeued, terminalState: res.terminalState || null, ...(conversion ? { conversion } : {}) });
      } else {
        failed += 1;
        consecutiveFailures += 1;
        results.push({ ...base, outcome: 'failed', attempts: res.attempts, requeued: !!res.requeued, terminalState: res.terminalState || null, reason: String((res.result && res.result.error) || 'Task failed.').slice(0, 300) });
      }
    }
    // A short page means the queue is exhausted — no further page can
    // return rows (the cursor already sits past the last row read).
    if (rows.length < pageLimit) break pageLoop;
  }

  return {
    ok: true, blocked: false, health, results,
    processed: results.length, done, failed, skipped, draftsConverted, stoppedReason,
  };
}

/**
 * One daily_reports row per (date, kind): update the existing row when a
 * workflow re-runs the same day instead of inserting a duplicate. The
 * live DB may already hold duplicate (date, kind) pairs from before this
 * fix, so no UNIQUE index is added — the first matching row is updated.
 */
async function upsertReport(env, date, kind, summary) {
  const existing = await d1First(env,
    'SELECT id FROM daily_reports WHERE date = ? AND kind = ? ORDER BY id ASC LIMIT 1', [date, kind]);
  if (existing) {
    await d1Run(env, 'UPDATE daily_reports SET summary_json = ?, created_at = ? WHERE id = ?',
      [JSON.stringify(summary), nowIso(), existing.id]);
    return { reportId: existing.id, duplicate: true };
  }
  const inserted = await d1Run(env,
    'INSERT INTO daily_reports (date, kind, summary_json, created_at) VALUES (?, ?, ?, ?)',
    [date, kind, JSON.stringify(summary), nowIso()]);
  return { reportId: inserted && inserted.meta ? inserted.meta.last_row_id : null, duplicate: false };
}

/** d1All that degrades to null when a table does not exist yet (a DB that has not applied migrations 008-011). */
async function safeAll(env, sql, params = []) {
  try {
    return await d1All(env, sql, params);
  } catch {
    return null;
  }
}

async function safeFirstRow(env, sql, params = []) {
  try {
    return await d1First(env, sql, params);
  } catch {
    return null;
  }
}

async function divisionCounts(env) {
  const rows = await d1All(env,
    'SELECT d.id, d.slug AS division, d.name, COUNT(a.id) AS total, ' +
    "SUM(CASE WHEN a.status = 'published' THEN 1 ELSE 0 END) AS published " +
    'FROM business_divisions d LEFT JOIN articles a ON a.division_id = d.id ' +
    'GROUP BY d.id, d.slug, d.name ORDER BY published ASC, total ASC');
  return (rows || []).map((r) => ({
    id: r.id, division: r.division, name: r.name, total: Number(r.total || 0), published: Number(r.published || 0),
  }));
}

async function step(env, agent, label, fn) {
  try {
    const result = await fn();
    const outcome = result && result.outcome === 'failed' ? 'failed' : (result && result.outcome === 'no-op' ? 'no-op' : 'done');
    await writeRun(env, {
      taskId: null, agent, outcome,
      detail: { step: label, ...(result || {}) },
      logs: [{ level: outcome === 'failed' ? 'error' : 'info', message: `${label}: ${outcome}.` }],
    });
    return { step: label, outcome, result: result || {} };
  } catch (err) {
    const error = String(err && err.message ? err.message : err).slice(0, 300);
    await writeRun(env, {
      taskId: null, agent, outcome: 'failed',
      detail: { step: label, error },
      logs: [{ level: 'error', message: `${label} failed: ${error}` }],
    });
    return { step: label, outcome: 'failed', error };
  }
}

/**
 * Daily workflow. Steps: (0) drain the queue (W1: runHealthCheck,
 * then runTask per eligible queued task, oldest-first, max 10
 * ATTEMPTED per run — skipped tasks do not consume a slot, B2);
 * (1) security health check; (2) enqueue research
 * for the two thinnest divisions; (3) fetch RSS inline when
 * auto_research is on; (4) enqueue content tasks from today's fresh
 * research items when auto_generation is on (daily limit respected);
 * (5) enqueue fact-checks for pending_approval articles; (6) run
 * fact-checks inline when auto_factcheck is on; (7) run corrections
 * inline when auto_correction is on; (8) run SEO checks inline for
 * drafts; (9) evaluate the publish gate for every draft (approves only
 * when auto_publishing is on AND the publishing mode permits it —
 * with the live default 'approved_only' nothing auto-publishes);
 * (10) publish due articles; (11) enqueue social packs for articles
 * published in the last 24h (max 5); (12) analytics snapshot;
 * (13) error scan; (15) Daily Autonomy Health Report (A5 — reuses the
 * queue drain's runHealthCheck result, stored in summary.healthReport);
 * (14) write the daily_reports row.
 *
 * One run per UTC date unless { force: true }. The report row is
 * upserted, so a forced re-run never creates a duplicate row.
 * All dates are UTC; 00:00 UTC is 06:00 Asia/Dhaka.
 */

/**
 * Fix Pass 2 item 4 (2026-11-23): true only when the latest seo_checks
 * row for the article covers the article's CURRENT body — the same
 * body_hash (the bodyHash helper, exactly as insertSeoCheck stores it)
 * AND the same body_length. A row with a NULL hash or length
 * (pre-migration-023) is never fresh. Any read failure (missing
 * columns on a DB without migration 023, missing table, ...) is NOT
 * fresh: the safe direction is to re-check, never to skip on
 * unproven freshness — a failed lookup costs one SEO check, a wrong
 * skip would starve the article again.
 */
async function isSeoFreshForCurrentBody(env, articleId) {
  try {
    const article = await d1First(env, 'SELECT body FROM articles WHERE id = ? LIMIT 1', [articleId]);
    if (!article) return false;
    const body = String(article.body || '');
    const latest = await d1First(env,
      'SELECT body_hash, body_length FROM seo_checks WHERE article_id = ? ORDER BY created_at DESC LIMIT 1',
      [articleId]);
    if (!latest || !latest.body_hash || latest.body_length == null) return false;
    return (await bodyHash(body)) === latest.body_hash && body.length === Number(latest.body_length);
  } catch {
    return false;
  }
}

/**
 * Fix Pass 3 A3 (2026-11-23): the fact-check twin of
 * isSeoFreshForCurrentBody — true only when the latest fact_checks
 * row for the article covers the article's CURRENT body.
 *
 * ONE HONEST DIFFERENCE from the SEO helper: fact_checks has NO
 * body_length column (migration 009 creates the table without one;
 * migration 019 adds body_hash ONLY — verified from the migration
 * files, no column was invented and no migration was added here).
 * Freshness is therefore the body_hash match alone — which is also
 * exactly the staleness rule evaluatePublishGate() already applies
 * to fact_checks (migration 019 header). A row with a NULL hash
 * (pre-migration-019) is never fresh. Any read failure (missing
 * column on a DB without migration 019, missing table, ...) is NOT
 * fresh: the safe direction is to re-check, never to skip on
 * unproven freshness — a failed lookup costs one fact-check, a wrong
 * skip would starve the article again.
 *
 * Any verdict counts as fresh: a body already judged (pass,
 * needs-review or failed) needs no fresh judgment until it changes;
 * needs-review/failed rows are the correctionRun step's job, not
 * this step's. The latest row is picked by created_at DESC, id DESC
 * (same as checkArticle's own previous-check lookup) so two rows
 * written in the same second resolve deterministically.
 */
async function isFactCheckFreshForCurrentBody(env, articleId) {
  try {
    const article = await d1First(env, 'SELECT body FROM articles WHERE id = ? LIMIT 1', [articleId]);
    if (!article) return false;
    const body = String(article.body || '');
    const latest = await d1First(env,
      'SELECT body_hash FROM fact_checks WHERE article_id = ? ORDER BY created_at DESC, id DESC LIMIT 1',
      [articleId]);
    if (!latest || !latest.body_hash) return false;
    return (await bodyHash(body)) === latest.body_hash;
  } catch {
    return false;
  }
}

export async function runDailyWorkflow(env, { force = false, fetchImpl = fetch } = {}) {
  if (!env || !env.DB) return { ok: false, error: 'D1 database is not bound.' };
  const date = todayStr();
  if (await getEmergencyStop(env)) {
    await logSkip(env, 'scheduler', 'Emergency Stop is on — daily workflow skipped.');
    return { ok: true, skipped: true, reason: 'Emergency Stop is on.', date };
  }
  // Phase 4: recover any task orphaned in 'running' by a stalled run
  // before starting new work — best effort, never blocks the workflow.
  try { await recoverStaleTasks(env); } catch { /* recovery is best-effort */ }
  if (!force) {
    const existing = await d1First(env, "SELECT id FROM daily_reports WHERE date = ? AND kind = 'daily' LIMIT 1", [date]);
    if (existing) {
      return { ok: true, date, duplicate: true, reportId: existing.id, reason: 'Daily workflow already ran today — pass force to re-run.' };
    }
  }
  const flags = await autoFlags(env);
  const dailyLimit = await maxArticlesPerDay(env);
  const steps = {};

  // W1 (2026-11-21): drain the queue. Before this step the daily
  // workflow enqueued tasks and did the same work inline without ever
  // calling runTask, so queued tasks were never executed (12 queued,
  // 0 running on 2026-11-21). The drain runs FIRST — before the
  // enqueue steps below — so this run executes the backlog; tasks
  // enqueued by this run drain on the next run. The weekly workflow
  // needs no separate drain: it fires inside the same 00:00 UTC
  // invocation as the daily workflow.
  steps.queueDrain = await step(env, 'scheduler', 'queue-drain', async () => {
    const drain = await drainTaskQueue(env);
    if (drain.blocked) {
      return {
        outcome: 'failed', blocked: true, stoppedReason: drain.stoppedReason,
        healthOverall: drain.health ? drain.health.overall : null,
        health: drain.health,
        reason: 'Self-health check blocked the queue drain — no queued task was started.',
      };
    }
    return {
      outcome: 'done',
      processed: drain.processed, done: drain.done, failed: drain.failed, skipped: drain.skipped,
      stoppedReason: drain.stoppedReason,
      healthOverall: drain.health ? drain.health.overall : null,
      // A5: the health-report step reads this — drainTaskQueue already
      // computed runHealthCheck, so the report reuses it instead of
      // calling runHealthCheck a second time (which would double-write
      // system_health_checks rows). The blocked branch already carried
      // it; the done branch dropped it, which would have left the
      // report's workerHealth/queue checks NOT TESTED on every run.
      health: drain.health,
      results: drain.results,
    };
  });

  steps.healthCheck = await step(env, 'security-monitoring', 'health-check', async () => {
    const r = await runAutonomyTask({ agent: 'security-monitoring', kind: 'health-check', payload: {} }, env);
    return { ...r, checks: (r.checks || []).length };
  });

  steps.topicSelection = await step(env, 'research', 'topic-selection', async () => {
    const counts = await divisionCounts(env);
    const thinnest = counts.slice(0, 2);
    let enqueued = 0;
    let duplicates = 0;
    for (const d of thinnest) {
      const res = await enqueueTask(env, {
        agent: 'research', kind: 'daily-research', payload: { division: d.division },
        division_id: d.id, priority: 5, idempotency_key: `daily-research-${d.division}-${date}`,
      });
      if (res.ok) (res.duplicate ? duplicates++ : enqueued++);
    }
    return { outcome: 'done', thinnest: thinnest.map((d) => d.division), enqueued, duplicates };
  });

  steps.researchFetch = await step(env, 'research', 'research-fetch', async () => {
    if (flags.auto_research !== 'on') return { outcome: 'no-op', reason: 'auto_research is off.' };
    const counts = await divisionCounts(env);
    const thinnest = counts.slice(0, 2);
    let fetched = 0;
    let added = 0;
    const errors = [];
    for (const d of thinnest) {
      const r = await runResearch({ agent: 'research', kind: 'daily-research', payload: { division: d.division } }, env);
      if (r.outcome === 'done') { fetched += (r.candidates || []).length; added += r.itemsStored || 0; }
      else if (r.outcome === 'failed') errors.push({ division: d.division, error: r.error });
      else if (Array.isArray(r.fetchErrors)) errors.push(...r.fetchErrors);
    }
    return { outcome: errors.length && !fetched ? 'failed' : 'done', divisions: thinnest.map((d) => d.division), fetched, added, errors };
  });

  steps.contentFromResearch = await step(env, 'content-creation', 'content-from-research', async () => {
    if (flags.auto_generation !== 'on') return { outcome: 'no-op', reason: 'auto_generation is off.' };
    const items = await d1All(env,
      'SELECT ri.id, ri.title, ri.url, ri.division_id, d.slug AS division FROM research_items ri ' +
      "JOIN business_divisions d ON d.id = ri.division_id WHERE ri.is_outdated = 0 AND ri.fetched_at >= datetime('now', '-1 day') " +
      'ORDER BY ri.fetched_at DESC LIMIT 20') || [];
    const existing = await d1All(env, 'SELECT title FROM articles') || [];
    const existingTitles = new Set(existing.map((r) => String(r.title || '').toLowerCase().trim()));
    let enqueued = 0;
    let duplicates = 0;
    let skippedExisting = 0;
    for (const item of items) {
      if (enqueued >= dailyLimit) break;
      if (existingTitles.has(String(item.title).toLowerCase().trim())) { skippedExisting += 1; continue; }
      const res = await enqueueTask(env, {
        agent: 'content-creation', kind: 'daily-content',
        payload: { title: item.title, division: item.division, sources: item.url ? [item.url] : [] },
        division_id: item.division_id, priority: 6, idempotency_key: `daily-content-${item.id}-${date}`,
      });
      if (res.ok) (res.duplicate ? duplicates++ : enqueued++);
    }
    return { outcome: 'done', candidates: items.length, enqueued, duplicates, skippedExisting, dailyLimit };
  });

  steps.factCheckQueue = await step(env, 'fact-checking', 'fact-check-queue', async () => {
    const rows = await d1All(env, "SELECT id FROM articles WHERE status = 'pending_approval' ORDER BY updated_at ASC") || [];
    let enqueued = 0;
    let duplicates = 0;
    for (const r of rows) {
      const res = await enqueueTask(env, {
        agent: 'fact-checking', kind: 'fact-check', payload: { article_id: r.id },
        priority: 6, idempotency_key: `daily-factcheck-${r.id}-${date}`,
      });
      if (res.ok) (res.duplicate ? duplicates++ : enqueued++);
    }
    return { outcome: 'done', pendingApproval: rows.length, enqueued, duplicates };
  });

  steps.factCheckRun = await step(env, 'fact-checking', 'fact-check-run', async () => {
    if (flags.auto_factcheck !== 'on') return { outcome: 'no-op', reason: 'auto_factcheck is off.' };
    // Fix Pass 3 A3 (2026-11-23): same starvation fix as seoRun in
    // Fix Pass 2 item 4 — fetch more candidates than the daily budget
    // so the loop can reach past drafts whose latest fact-check is
    // already fresh for their current body. The old LIMIT 3 re-checked
    // the same oldest drafts every day while newer drafts starved.
    // The budget stays 3 REAL checks. NOTE: this step deliberately
    // keeps its original selection (no protectedExclusion guard):
    // fact-checking is advisory/read-only — it never modifies an
    // article — so #26/#27 need no exclusion here, unlike seoRun and
    // correctionRun. That behaviour is unchanged.
    const rows = await d1All(env, "SELECT id FROM articles WHERE status IN ('draft', 'pending_approval') ORDER BY updated_at ASC LIMIT 10") || [];
    const results = [];
    let checked = 0;
    let skippedFresh = 0;
    for (const r of rows) {
      if (checked >= 3) break;
      if (await isFactCheckFreshForCurrentBody(env, r.id)) {
        skippedFresh += 1;
        results.push({ articleId: r.id, outcome: 'skipped-fresh' });
        continue;
      }
      const res = await runFactChecking({ agent: 'fact-checking', kind: 'fact-check', payload: { article_id: r.id } }, env);
      results.push({ articleId: r.id, outcome: res.outcome, verdict: res.verdict || null });
      checked += 1;
    }
    return { outcome: 'done', checked, skippedFresh, results };
  });

  steps.correctionRun = await step(env, 'fact-checking', 'correction-run', async () => {
    if (flags.auto_correction !== 'on') return { outcome: 'no-op', reason: 'auto_correction is off.' };
    // Protected test articles #26/#27 are never auto-corrected (owner order).
    const guard = protectedExclusion('fc.article_id');
    const rows = await d1All(env,
      'SELECT DISTINCT fc.article_id AS id FROM fact_checks fc ' +
      "WHERE fc.verdict IN ('needs-review', 'failed') AND fc.created_at >= datetime('now', '-7 days') AND " + guard.clause + ' ' +
      "AND EXISTS (SELECT 1 FROM articles a WHERE a.id = fc.article_id AND a.status IN ('draft', 'pending_approval')) " +
      'ORDER BY fc.created_at DESC LIMIT 3', guard.params) || [];
    const results = [];
    for (const r of rows) {
      const res = await runFactChecking({ agent: 'fact-checking', kind: 'correct', payload: { article_id: r.id } }, env);
      results.push({ articleId: r.id, outcome: res.outcome, corrected: res.corrected ?? 0, removed: res.removed ?? 0 });
    }
    return { outcome: 'done', corrected: results.length, results };
  });

  steps.seoRun = await step(env, 'seo', 'seo-run', async () => {
    // Protected test articles #26/#27 are never auto-repaired (owner order).
    const guard = protectedExclusion('id');
    // Fix Pass 2 item 4 (2026-11-23): fetch more candidates than the
    // daily budget so the loop can reach past drafts whose latest SEO
    // check is already fresh for their current body. The old LIMIT 3
    // starved #33/#30 behind unchanged #28/#31/#29 (oldest updated_at
    // first, re-checked every day). The budget stays 3 REAL checks.
    const rows = await d1All(env, "SELECT id FROM articles WHERE status IN ('draft', 'pending_approval') AND " + guard.clause + ' ORDER BY updated_at ASC LIMIT 10', guard.params) || [];
    const results = [];
    let checked = 0;
    let skippedFresh = 0;
    for (const r of rows) {
      if (checked >= 3) break;
      if (await isSeoFreshForCurrentBody(env, r.id)) {
        skippedFresh += 1;
        results.push({ articleId: r.id, outcome: 'skipped-fresh' });
        continue;
      }
      const res = await runSeo({ agent: 'seo', kind: 'seo-pass', payload: { article_id: r.id } }, env);
      results.push({ articleId: r.id, outcome: res.outcome, verdict: res.verdict || null });
      checked += 1;
    }
    return { outcome: 'done', checked, skippedFresh, results };
  });

  steps.seoPass = await step(env, 'seo', 'seo-pass', async () => {
    const rows = await d1All(env,
      "SELECT id FROM articles WHERE status = 'published' AND (seo_title IS NULL OR seo_title = '' OR seo_description IS NULL OR seo_description = '') ORDER BY updated_at ASC LIMIT 5") || [];
    let enqueued = 0;
    let duplicates = 0;
    for (const r of rows) {
      const res = await enqueueTask(env, {
        agent: 'seo', kind: 'seo-pass', payload: { article_id: r.id },
        priority: 5, idempotency_key: `daily-seo-${r.id}-${date}`,
      });
      if (res.ok) (res.duplicate ? duplicates++ : enqueued++);
    }
    return { outcome: 'done', needingSeo: rows.length, enqueued, duplicates };
  });

  steps.publishGate = await step(env, 'publishing', 'publish-gate', async () => {
    const rows = await d1All(env, "SELECT id FROM articles WHERE status IN ('draft', 'pending_approval') ORDER BY updated_at ASC") || [];
    const results = [];
    let approved = 0;
    for (const r of rows) {
      const gate = await evaluatePublishGate(env, r.id);
      let wasApproved = false;
      if (gate.eligible && flags.auto_publishing === 'on') {
        const pub = await publishGatePassed(env, r.id, { dailyLimit });
        wasApproved = Boolean(pub.ok);
        if (wasApproved) approved += 1;
      }
      results.push({ articleId: r.id, eligible: gate.eligible, approved: wasApproved, blockedBy: gate.blockedBy });
    }
    return { outcome: 'done', evaluated: results.length, approved, results, autoPublishing: flags.auto_publishing };
  });

  steps.publishDue = await step(env, 'publishing', 'publish-due', async () => {
    const r = await publishDueArticles(env);
    if (!r.ok) return { outcome: 'failed', error: r.error || 'Publish due failed.' };
    if (r.skipped) return { outcome: 'no-op', reason: r.reason, published: 0 };
    return { outcome: 'done', published: r.published || 0, slugs: r.slugs || [] };
  });

  // Autonomous publish (W3, coordinator-wired): tries NEW candidate
  // drafts only (created after the owner-set cutoff, never legacy
  // #28/#29/#30/#31, never protected). runAutoPublish() itself
  // pre-flights the two master flags + E-Stop + cutoff and no-ops
  // with zero log rows when disabled, so with the live defaults
  // (approved_only / off / unset) this step does nothing.
  steps.autoPublish = await step(env, 'publishing', 'auto-publish', async () => {
    const r = await runAutoPublish(env);
    return r;
  });

  steps.socialPrep = await step(env, 'social-media', 'social-pack-prep', async () => {
    const rows = await d1All(env,
      "SELECT id FROM articles WHERE status = 'published' AND published_at >= datetime('now', '-1 day') ORDER BY published_at DESC LIMIT 5") || [];
    let enqueued = 0;
    let duplicates = 0;
    for (const r of rows) {
      const res = await enqueueTask(env, {
        agent: 'social-media', kind: 'social-pack', payload: { article_id: r.id },
        priority: 4, idempotency_key: `daily-social-${r.id}-${date}`,
      });
      if (res.ok) (res.duplicate ? duplicates++ : enqueued++);
    }
    return { outcome: 'done', publishedLast24h: rows.length, enqueued, duplicates };
  });

  steps.analyticsSnapshot = await step(env, 'analytics', 'analytics-snapshot', async () => {
    const r = await runAutonomyTask({ agent: 'analytics', kind: 'snapshot', payload: {} }, env);
    return r;
  });

  steps.errorScan = await step(env, 'security-monitoring', 'error-scan', async () => {
    const failedRow = await d1First(env, "SELECT COUNT(*) AS n FROM agent_tasks WHERE status = 'failed'");
    const eventsRow = await d1First(env, "SELECT COUNT(*) AS n FROM security_events WHERE created_at >= datetime('now', '-7 days')");
    const failedTasks = Number(failedRow ? failedRow.n : 0);
    const securityEvents = Number(eventsRow ? eventsRow.n : 0);
    return {
      outcome: 'done', failedTasks, securityEventsLast7Days: securityEvents,
      detail: `${failedTasks} failed task(s), ${securityEvents} security event(s) in the last 7 days.`,
    };
  });

  // (15) Daily Autonomy Health Report (close-out A5, 2026-11-23;
  // Fix Pass 4 F1, 2026-11-24): owner-only, produced by this existing
  // daily run — no new cron. The report reuses the runHealthCheck
  // result the queue drain already computed (steps.queueDrain.result
  // .health) — it never calls runHealthCheck again (that writes rows).
  // The five external-fetch checks (pages, sitemap, recentArticles,
  // sitemapRefresh, serverSideHeads) are fetched from the internal
  // route first: that route runs in its own Worker invocation with a
  // fresh 50-subrequest budget, because this invocation's budget is
  // already spent by the drain + SEO steps by the time the report
  // runs (on 24 Nov they failed with "Too many subrequests"). The
  // route is called exactly once; any failure returns null and the
  // builder falls back to the in-process checks (today's behaviour —
  // a fetch failure is still reported as FAIL, never OK). The step
  // wrapper isolates failures, so a builder throw can never abort the
  // run; the builder itself also never throws (every check is
  // individually try/caught). The report lands in summary.healthReport,
  // which upsertReport stores in the daily_reports row — that is the
  // report's home; no new table. Read-only: it never publishes,
  // edits or fixes anything.
  steps.healthReport = await step(env, 'scheduler', 'health-report', async () => {
    const nowMs = Date.now();
    let externalChecks = null;
    try {
      externalChecks = await fetchExternalHealthChecks(env, { fetchImpl, nowMs });
    } catch {
      externalChecks = null;
    }
    const report = await buildDailyHealthReport(env, {
      health: steps.queueDrain.result?.health || null,
      fetchImpl,
      nowMs,
      externalChecks,
    });
    return { outcome: 'done', ...report };
  });

  const summary = {
    date,
    kind: 'daily',
    healthReport: steps.healthReport.result || null,
    steps: Object.fromEntries(Object.entries(steps).map(([k, v]) => [k, { outcome: v.outcome, ...(v.error ? { error: v.error } : {}) }])),
    counts: {
      queueDrained: steps.queueDrain.result?.processed ?? 0,
      queueDone: steps.queueDrain.result?.done ?? 0,
      queueFailed: steps.queueDrain.result?.failed ?? 0,
      queueSkipped: steps.queueDrain.result?.skipped ?? 0,
      queueDraftsConverted: steps.queueDrain.result?.draftsConverted ?? 0,
      queueHealthOverall: steps.queueDrain.result?.healthOverall ?? null,
      researchEnqueued: steps.topicSelection.result?.enqueued ?? 0,
      researchFetched: steps.researchFetch.result?.fetched ?? 0,
      researchItemsStored: steps.researchFetch.result?.added ?? 0,
      contentEnqueued: steps.contentFromResearch.result?.enqueued ?? 0,
      factChecksEnqueued: steps.factCheckQueue.result?.enqueued ?? 0,
      factChecksRun: steps.factCheckRun.result?.checked ?? 0,
      correctionsRun: steps.correctionRun.result?.corrected ?? 0,
      seoRun: steps.seoRun.result?.checked ?? 0,
      seoEnqueued: steps.seoPass.result?.enqueued ?? 0,
      gateEvaluated: steps.publishGate.result?.evaluated ?? 0,
      gateApproved: steps.publishGate.result?.approved ?? 0,
      published: steps.publishDue.result?.published ?? 0,
      socialEnqueued: steps.socialPrep.result?.enqueued ?? 0,
      failedTasks: steps.errorScan.result?.failedTasks ?? 0,
      securityEventsLast7Days: steps.errorScan.result?.securityEventsLast7Days ?? 0,
    },
    autoFlags: flags,
    dailyLimit,
    revenue: 0,
    revenueFormatted: '$0.00',
    traffic: 'Data unavailable',
  };
  let reportId = null;
  let duplicateReport = false;
  try {
    const saved = await upsertReport(env, date, 'daily', summary);
    reportId = saved.reportId;
    duplicateReport = saved.duplicate;
  } catch (err) {
    summary.reportError = String(err && err.message ? err.message : err).slice(0, 200);
  }
  // `duplicate` means "this call did not re-run" — a forced re-run DID
  // run, so it reports no duplicate even though it updated the row.
  return { ok: true, date, reportId, duplicate: (!force && duplicateReport) ? true : undefined, steps: summary.steps, counts: summary.counts };
}

/**
 * Weekly workflow: performance analysis from real D1 data — articles by
 * division, task outcomes in the last 7 days, failed tasks list, top
 * divisions, failed RSS sources, fact-check failures, successful topics,
 * content gaps, SEO problems, and improvement recommendations derived
 * from that data — plus a weekly daily_reports row.
 *
 * One run per UTC week-date unless { force: true }. The report row is
 * upserted, so a forced re-run never creates a duplicate row.
 */
export async function runWeeklyWorkflow(env, { force = false } = {}) {
  if (!env || !env.DB) return { ok: false, error: 'D1 database is not bound.' };
  const date = todayStr();
  if (await getEmergencyStop(env)) {
    await logSkip(env, 'scheduler', 'Emergency Stop is on — weekly workflow skipped.');
    return { ok: true, skipped: true, reason: 'Emergency Stop is on.', date };
  }
  // Phase 4: recover any task orphaned in 'running' by a stalled run
  // before starting new work — best effort, never blocks the workflow.
  try { await recoverStaleTasks(env); } catch { /* recovery is best-effort */ }
  if (!force) {
    const existing = await d1First(env, "SELECT id FROM daily_reports WHERE date = ? AND kind = 'weekly' LIMIT 1", [date]);
    if (existing) {
      return { ok: true, date, duplicate: true, reportId: existing.id, reason: 'Weekly workflow already ran today — pass force to re-run.' };
    }
  }
  const byDivision = await divisionCounts(env);
  const outcomes = await d1All(env,
    "SELECT outcome, COUNT(*) AS n FROM agent_runs WHERE started_at >= datetime('now', '-7 days') GROUP BY outcome") || [];
  const taskOutcomes = Object.fromEntries(outcomes.map((r) => [r.outcome, Number(r.n || 0)]));
  const failedTasks = await d1All(env,
    "SELECT id, agent, kind, attempts, max_attempts, updated_at FROM agent_tasks WHERE status = 'failed' ORDER BY updated_at DESC LIMIT 20") || [];
  const topDivisions = [...byDivision].sort((a, b) => b.published - a.published).slice(0, 3);
  const totalsRow = await d1First(env, 'SELECT COUNT(*) AS n FROM articles');
  const publishedRow = await d1First(env, "SELECT COUNT(*) AS n FROM articles WHERE status = 'published'");

  // Failed RSS sources (real health rows). These queries degrade to
  // empty on a DB that has not applied migrations 008-011 yet, so the
  // weekly report still writes instead of throwing.
  const failedSourcesRaw = await safeAll(env,
    "SELECT s.id, s.name, s.url, d.slug AS division, s.last_error, s.last_fetched_at FROM research_sources s " +
    "JOIN business_divisions d ON d.id = s.division_id WHERE s.is_active = 1 AND s.last_status = 'error' ORDER BY s.updated_at DESC");
  const failedSources = failedSourcesRaw || [];
  const sourceTotals = await safeFirstRow(env, 'SELECT COUNT(*) AS n FROM research_sources WHERE is_active = 1');
  const itemTotals = await safeFirstRow(env, "SELECT COUNT(*) AS n FROM research_items WHERE fetched_at >= datetime('now', '-7 days')");
  const itemsByDivisionRaw = await safeAll(env,
    'SELECT d.slug AS division, COUNT(*) AS n FROM research_items ri JOIN business_divisions d ON d.id = ri.division_id ' +
    "WHERE ri.fetched_at >= datetime('now', '-7 days') GROUP BY d.slug ORDER BY n DESC");
  const itemsByDivision = itemsByDivisionRaw || [];

  // Fact-check failures in the last 7 days.
  const factCheckFailuresRaw = await safeAll(env,
    'SELECT fc.id, fc.article_id, fc.verdict, fc.claims_total, fc.claims_verified, fc.claims_failed, fc.created_at ' +
    "FROM fact_checks fc WHERE fc.verdict IN ('needs-review', 'failed') AND fc.created_at >= datetime('now', '-7 days') ORDER BY fc.created_at DESC LIMIT 20");
  const factCheckFailures = factCheckFailuresRaw || [];
  const factCheckTotalsRaw = await safeAll(env,
    "SELECT verdict, COUNT(*) AS n FROM fact_checks WHERE created_at >= datetime('now', '-7 days') GROUP BY verdict");
  const factCheckTotals = factCheckTotalsRaw || [];

  // SEO problems in the last 7 days.
  const seoProblemsRaw = await safeAll(env,
    'SELECT sc.id, sc.article_id, sc.verdict, sc.created_at FROM seo_checks sc ' +
    "WHERE sc.verdict IN ('needs-review', 'failed') AND sc.created_at >= datetime('now', '-7 days') ORDER BY sc.created_at DESC LIMIT 20");
  const seoProblems = seoProblemsRaw || [];
  const pipelineTablesMissing = failedSourcesRaw === null || factCheckFailuresRaw === null || seoProblemsRaw === null;

  // Content gaps: divisions with the fewest published articles.
  const contentGaps = byDivision.filter((d) => d.published === 0).map((d) => ({ division: d.division, published: 0, total: d.total }));
  const thinnest = byDivision.slice(0, 3).map((d) => ({ division: d.division, published: d.published, total: d.total }));

  // Recommendations derived from the data above — never invented.
  const recommendations = [];
  if (failedSources.length) {
    recommendations.push(`${failedSources.length} RSS source(s) failed their last fetch — check the URLs in Research Sources and disable or replace any that stay down.`);
  }
  if (factCheckFailures.length) {
    recommendations.push(`${factCheckFailures.length} article(s) failed fact-checking in the last 7 days — run corrections and re-check before they can publish.`);
  }
  if (seoProblems.length) {
    recommendations.push(`${seoProblems.length} article(s) have SEO problems — fill missing titles/descriptions and fix the flagged checks.`);
  }
  if (contentGaps.length) {
    recommendations.push(`Divisions with no published articles yet: ${contentGaps.map((g) => g.division).join(', ')} — prioritise research and generation there.`);
  }
  if (failedTasks.length) {
    recommendations.push(`${failedTasks.length} failed task(s) are waiting — retry them from the task queue or investigate the logged errors.`);
  }
  if (!recommendations.length) {
    recommendations.push('No blocking issues this week — keep the daily Short + Pin cadence and the weekly long video going.');
  }
  if (pipelineTablesMissing) {
    recommendations.push('Research / fact-check / SEO tables are missing (migrations 008-011 not applied yet) — those sections of this report are empty until the migrations are applied.');
  }

  const summary = {
    date,
    kind: 'weekly',
    articlesByDivision: byDivision,
    totalArticles: Number(totalsRow ? totalsRow.n : 0),
    publishedArticles: Number(publishedRow ? publishedRow.n : 0),
    taskOutcomesLast7Days: taskOutcomes,
    failedTasks: failedTasks.map((t) => ({ id: t.id, agent: t.agent, kind: t.kind, attempts: t.attempts, maxAttempts: t.max_attempts, updatedAt: t.updated_at })),
    failedTaskCount: failedTasks.length,
    topDivisions: topDivisions.map((d) => ({ division: d.division, published: d.published, total: d.total })),
    failedSources: failedSources.map((s) => ({ id: s.id, name: s.name, url: s.url, division: s.division, lastError: s.last_error, lastFetchedAt: s.last_fetched_at })),
    activeSources: Number(sourceTotals ? sourceTotals.n : 0),
    researchItemsLast7Days: Number(itemTotals ? itemTotals.n : 0),
    successfulTopicsByDivision: itemsByDivision.map((r) => ({ division: r.division, items: Number(r.n || 0) })),
    factCheckFailures: factCheckFailures.map((f) => ({ id: f.id, articleId: f.article_id, verdict: f.verdict, claimsTotal: f.claims_total, claimsVerified: f.claims_verified, claimsFailed: f.claims_failed, createdAt: f.created_at })),
    factCheckTotalsLast7Days: Object.fromEntries(factCheckTotals.map((r) => [r.verdict, Number(r.n || 0)])),
    seoProblems: seoProblems.map((s) => ({ id: s.id, articleId: s.article_id, verdict: s.verdict, createdAt: s.created_at })),
    contentGaps,
    thinnestDivisions: thinnest,
    recommendations,
    revenue: 0,
    revenueFormatted: '$0.00',
    traffic: 'Data unavailable',
  };
  let reportId = null;
  let duplicateReport = false;
  try {
    const saved = await upsertReport(env, date, 'weekly', summary);
    reportId = saved.reportId;
    duplicateReport = saved.duplicate;
  } catch (err) {
    summary.reportError = String(err && err.message ? err.message : err).slice(0, 200);
  }
  await writeRun(env, {
    taskId: null, agent: 'scheduler', outcome: 'done',
    detail: { step: 'weekly-report', reportId },
    logs: [{ level: 'info', message: `Weekly report written (id ${reportId}).` }],
  });
  return { ok: true, date, reportId, duplicate: (!force && duplicateReport) ? true : undefined, summary };
}

/**
 * Report snapshot from current D1 data — used by POST
 * /api/autonomy/reports/generate. This does NOT re-execute any workflow
 * or agent task; it only reads current state and stores the row.
 */
export async function generateReportSnapshot(env, kind) {
  if (!env || !env.DB) return { ok: false, error: 'D1 database is not bound.' };
  const date = todayStr();
  const taskCounts = await d1All(env, 'SELECT status, COUNT(*) AS n FROM agent_tasks GROUP BY status') || [];
  const agentStatuses = await d1All(env, 'SELECT status, COUNT(*) AS n FROM ai_agents GROUP BY status') || [];
  const articlesByDivision = await divisionCounts(env);
  const articlesByStatus = await d1All(env, 'SELECT status, COUNT(*) AS n FROM articles GROUP BY status') || [];
  const failedTasks = await d1All(env,
    "SELECT id, agent, kind, attempts, max_attempts, updated_at FROM agent_tasks WHERE status = 'failed' ORDER BY updated_at DESC LIMIT 20") || [];
  const summary = {
    date,
    kind,
    generatedAt: nowIso(),
    tasksByStatus: Object.fromEntries(taskCounts.map((r) => [r.status, Number(r.n || 0)])),
    agentsByStatus: Object.fromEntries(agentStatuses.map((r) => [r.status, Number(r.n || 0)])),
    articlesByDivision,
    articlesByStatus: Object.fromEntries(articlesByStatus.map((r) => [r.status, Number(r.n || 0)])),
    failedTasks: failedTasks.map((t) => ({ id: t.id, agent: t.agent, kind: t.kind, attempts: t.attempts, maxAttempts: t.max_attempts, updatedAt: t.updated_at })),
    revenue: 0,
    revenueFormatted: '$0.00',
    traffic: 'Data unavailable',
    note: 'Snapshot of current D1 state — no workflow was executed to generate it.',
  };
  const inserted = await d1Run(env,
    'INSERT INTO daily_reports (date, kind, summary_json, created_at) VALUES (?, ?, ?, ?)',
    [date, kind, JSON.stringify(summary), nowIso()]);
  const reportId = inserted && inserted.meta ? inserted.meta.last_row_id : null;
  const row = reportId ? await d1First(env, 'SELECT * FROM daily_reports WHERE id = ? LIMIT 1', [reportId]) : null;
  return { ok: true, report: row ? { ...row, summary } : { id: reportId, date, kind, summary_json: JSON.stringify(summary) } };
}
